﻿// SymmetryDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "SymmetryDlg.h"


// CSymmetryDlg 대화 상자

IMPLEMENT_DYNAMIC(CSymmetryDlg, CDialog)

CSymmetryDlg::CSymmetryDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_SYMMETRY, pParent)
	, m_symmetry(0)
{

}

CSymmetryDlg::~CSymmetryDlg()
{
}

void CSymmetryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_symmetry);
	DDV_MinMaxInt(pDX, m_symmetry, 1, 3);
}


BEGIN_MESSAGE_MAP(CSymmetryDlg, CDialog)
END_MESSAGE_MAP()


// CSymmetryDlg 메시지 처리기

﻿// EdgefirstDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "EdgefirstDlg.h"


// CEdgefirstDlg 대화 상자

IMPLEMENT_DYNAMIC(CEdgefirstDlg, CDialog)

CEdgefirstDlg::CEdgefirstDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_EDGEFIRST, pParent)
	, m_checkval1(0)
	, m_checkval2(0)
	, m_checkval3(0)
{

}

CEdgefirstDlg::~CEdgefirstDlg()
{
}

void CEdgefirstDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_checkval1);
	DDV_MinMaxInt(pDX, m_checkval1, 1, 3);
	DDX_Text(pDX, IDC_EDIT2, m_checkval2);
	DDV_MinMaxInt(pDX, m_checkval2, 1, 2);
	DDX_Text(pDX, IDC_EDIT3, m_checkval3);
	DDV_MinMaxInt(pDX, m_checkval3, 1, 2);
}


BEGIN_MESSAGE_MAP(CEdgefirstDlg, CDialog)
END_MESSAGE_MAP()


// CEdgefirstDlg 메시지 처리기

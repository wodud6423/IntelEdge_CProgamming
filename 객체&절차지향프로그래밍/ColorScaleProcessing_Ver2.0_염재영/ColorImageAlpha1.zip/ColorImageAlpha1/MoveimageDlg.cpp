﻿// MoveimageDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "MoveimageDlg.h"


// CMoveimageDlg 대화 상자

IMPLEMENT_DYNAMIC(CMoveimageDlg, CDialog)

CMoveimageDlg::CMoveimageDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MOVEIMAGE, pParent)
	, m_moveup(0)
	, m_moveright(0)
	, m_movedown(0)
	, m_moveleft(0)
{

}

CMoveimageDlg::~CMoveimageDlg()
{
}

void CMoveimageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT4, m_moveup);
	DDX_Text(pDX, IDC_EDIT1, m_moveright);
	DDX_Text(pDX, IDC_EDIT2, m_movedown);
	DDX_Text(pDX, IDC_EDIT3, m_moveleft);
}


BEGIN_MESSAGE_MAP(CMoveimageDlg, CDialog)
END_MESSAGE_MAP()


// CMoveimageDlg 메시지 처리기

﻿// ColoroutDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "ColoroutDlg.h"


// CColoroutDlg 대화 상자

IMPLEMENT_DYNAMIC(CColoroutDlg, CDialog)

CColoroutDlg::CColoroutDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_COLOROUT, pParent)
{

}

CColoroutDlg::~CColoroutDlg()
{
}

void CColoroutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CColoroutDlg, CDialog)
END_MESSAGE_MAP()


// CColoroutDlg 메시지 처리기

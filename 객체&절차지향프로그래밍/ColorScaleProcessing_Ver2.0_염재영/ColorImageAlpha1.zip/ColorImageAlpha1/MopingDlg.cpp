﻿// MopingDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "MopingDlg.h"


// CMopingDlg 대화 상자

IMPLEMENT_DYNAMIC(CMopingDlg, CDialog)

CMopingDlg::CMopingDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MOPING, pParent)
	, m_moping(0)
{

}

CMopingDlg::~CMopingDlg()
{
}

void CMopingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_moping);
	DDV_MinMaxInt(pDX, m_moping, 0, 100);
}


BEGIN_MESSAGE_MAP(CMopingDlg, CDialog)
END_MESSAGE_MAP()


// CMopingDlg 메시지 처리기

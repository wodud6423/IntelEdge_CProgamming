﻿#pragma once
#include "afxdialogex.h"


// CRealcoloroutDlg 대화 상자

class CRealcoloroutDlg : public CDialog
{
	DECLARE_DYNAMIC(CRealcoloroutDlg)

public:
	CRealcoloroutDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CRealcoloroutDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REALCOLOROUT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_colorval;
};

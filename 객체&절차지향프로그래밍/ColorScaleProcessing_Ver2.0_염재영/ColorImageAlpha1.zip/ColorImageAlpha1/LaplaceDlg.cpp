﻿// LaplaceDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "LaplaceDlg.h"


// CLaplaceDlg 대화 상자

IMPLEMENT_DYNAMIC(CLaplaceDlg, CDialog)

CLaplaceDlg::CLaplaceDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_LAPLACE, pParent)
	, m_laplace(0)
{

}

CLaplaceDlg::~CLaplaceDlg()
{
}

void CLaplaceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_laplace);
	DDV_MinMaxInt(pDX, m_laplace, 1, 3);
}


BEGIN_MESSAGE_MAP(CLaplaceDlg, CDialog)
END_MESSAGE_MAP()


// CLaplaceDlg 메시지 처리기

﻿// ChangesaturDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "ChangesaturDlg.h"


// CChangesaturDlg 대화 상자

IMPLEMENT_DYNAMIC(CChangesaturDlg, CDialog)

CChangesaturDlg::CChangesaturDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CHANGESATUR, pParent)
	, m_satur(0)
{

}

CChangesaturDlg::~CChangesaturDlg()
{
}

void CChangesaturDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_satur);
	DDV_MinMaxDouble(pDX, m_satur, 0, 1);
}


BEGIN_MESSAGE_MAP(CChangesaturDlg, CDialog)
END_MESSAGE_MAP()


// CChangesaturDlg 메시지 처리기

﻿// EdgedogDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "EdgedogDlg.h"


// CEdgedogDlg 대화 상자

IMPLEMENT_DYNAMIC(CEdgedogDlg, CDialog)

CEdgedogDlg::CEdgedogDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_EDGEDOG, pParent)
	, m_edgedog(0)
{

}

CEdgedogDlg::~CEdgedogDlg()
{
}

void CEdgedogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_edgedog);
	DDV_MinMaxInt(pDX, m_edgedog, 7, 9);
}


BEGIN_MESSAGE_MAP(CEdgedogDlg, CDialog)
END_MESSAGE_MAP()


// CEdgedogDlg 메시지 처리기

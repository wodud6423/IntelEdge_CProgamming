﻿#pragma once
#include "afxdialogex.h"


// CMoveimageDlg 대화 상자

class CMoveimageDlg : public CDialog
{
	DECLARE_DYNAMIC(CMoveimageDlg)

public:
	CMoveimageDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CMoveimageDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MOVEIMAGE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_moveup;
	int m_moveright;
	int m_movedown;
	int m_moveleft;
};

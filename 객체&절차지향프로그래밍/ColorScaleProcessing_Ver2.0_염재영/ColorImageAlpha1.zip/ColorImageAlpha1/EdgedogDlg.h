﻿#pragma once
#include "afxdialogex.h"


// CEdgedogDlg 대화 상자

class CEdgedogDlg : public CDialog
{
	DECLARE_DYNAMIC(CEdgedogDlg)

public:
	CEdgedogDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CEdgedogDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EDGEDOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_edgedog;
};

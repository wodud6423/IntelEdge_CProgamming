﻿#pragma once
#include "afxdialogex.h"


// CEdgefirstDlg 대화 상자

class CEdgefirstDlg : public CDialog
{
	DECLARE_DYNAMIC(CEdgefirstDlg)

public:
	CEdgefirstDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CEdgefirstDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EDGEFIRST };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_checkval1;
	int m_checkval2;
	int m_checkval3;
};

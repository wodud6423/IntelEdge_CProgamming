﻿// ChsaturDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "ChsaturDlg.h"


// CChsaturDlg 대화 상자

IMPLEMENT_DYNAMIC(CChsaturDlg, CDialog)

CChsaturDlg::CChsaturDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CHSATUR, pParent)
	, m_satur(0)
{

}

CChsaturDlg::~CChsaturDlg()
{
}

void CChsaturDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_satur);
	DDV_MinMaxDouble(pDX, m_satur, -1, 1);
}


BEGIN_MESSAGE_MAP(CChsaturDlg, CDialog)
END_MESSAGE_MAP()


// CChsaturDlg 메시지 처리기

﻿// LowsharpDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "LowsharpDlg.h"


// CLowsharpDlg 대화 상자

IMPLEMENT_DYNAMIC(CLowsharpDlg, CDialog)

CLowsharpDlg::CLowsharpDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_LOWSHARP, pParent)
	, m_alpha(0)
{

}

CLowsharpDlg::~CLowsharpDlg()
{
}

void CLowsharpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_alpha);
	DDV_MinMaxDouble(pDX, m_alpha, 0, DBL_MAX);
}


BEGIN_MESSAGE_MAP(CLowsharpDlg, CDialog)
END_MESSAGE_MAP()


// CLowsharpDlg 메시지 처리기

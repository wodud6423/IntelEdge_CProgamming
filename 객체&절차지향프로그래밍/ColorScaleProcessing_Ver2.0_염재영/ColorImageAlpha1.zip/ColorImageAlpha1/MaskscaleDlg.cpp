﻿// MaskscaleDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "MaskscaleDlg.h"


// CMaskscaleDlg 대화 상자

IMPLEMENT_DYNAMIC(CMaskscaleDlg, CDialog)

CMaskscaleDlg::CMaskscaleDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MASKSCALE, pParent)
	, m_maskscale(0)
{

}

CMaskscaleDlg::~CMaskscaleDlg()
{
}

void CMaskscaleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_maskscale);
	DDV_MinMaxInt(pDX, m_maskscale, 2, 200);
}


BEGIN_MESSAGE_MAP(CMaskscaleDlg, CDialog)
END_MESSAGE_MAP()


// CMaskscaleDlg 메시지 처리기

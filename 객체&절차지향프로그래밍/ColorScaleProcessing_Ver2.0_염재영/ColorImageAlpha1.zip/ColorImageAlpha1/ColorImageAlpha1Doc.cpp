﻿
// ColorImageAlpha1Doc.cpp: CColorImageAlpha1Doc 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ColorImageAlpha1.h"
#endif
#include "ColorImageAlpha1Doc.h"
#include "ConstantDlg.h"
#include "PosterDlg.h"
#include "SymmetryDlg.h"
#include "SharpmaskDlg.h"
#include "LowsharpDlg.h"
#include "MaskscaleDlg.h"
#include "RotateDlg.h"
#include "MopingDlg.h"
#include "MoveimageDlg.h"
#include "RealcoloroutDlg.h"
#include "WaterimageoutDlg.h"
#include "EdgefirstDlg.h"
#include "EdgedogDlg.h"
#include "LaplaceDlg.h"
#include "Impressimage.h"
#include "ChsaturDlg.h"
#include "GammaDlg.h"
#include <propkey.h>
#include <cstdlib>
#include <cmath>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CColorImageAlpha1Doc

IMPLEMENT_DYNCREATE(CColorImageAlpha1Doc, CDocument)

BEGIN_MESSAGE_MAP(CColorImageAlpha1Doc, CDocument)
END_MESSAGE_MAP()


// CColorImageAlpha1Doc 생성/소멸

CColorImageAlpha1Doc::CColorImageAlpha1Doc() noexcept
{
	// TODO: 여기에 일회성 생성 코드를 추가합니다.

}

CColorImageAlpha1Doc::~CColorImageAlpha1Doc()
{
}

BOOL CColorImageAlpha1Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 여기에 재초기화 코드를 추가합니다.
	// SDI 문서는 이 문서를 다시 사용합니다.

	return TRUE;
}




// CColorImageAlpha1Doc serialization

void CColorImageAlpha1Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 여기에 저장 코드를 추가합니다.
	}
	else
	{
		// TODO: 여기에 로딩 코드를 추가합니다.
	}
}

#ifdef SHARED_HANDLERS

// 축소판 그림을 지원합니다.
void CColorImageAlpha1Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 문서의 데이터를 그리려면 이 코드를 수정하십시오.
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 검색 처리기를 지원합니다.
void CColorImageAlpha1Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// 문서의 데이터에서 검색 콘텐츠를 설정합니다.
	// 콘텐츠 부분은 ";"로 구분되어야 합니다.

	// 예: strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CColorImageAlpha1Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CColorImageAlpha1Doc 진단

#ifdef _DEBUG
void CColorImageAlpha1Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CColorImageAlpha1Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CColorImageAlpha1Doc 명령


BOOL CColorImageAlpha1Doc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// 기존 메모리 해제
	if (m_inImageR != NULL) {
		OnFree2d(m_inImageR, m_inH);
		OnFree2d(m_inImageG, m_inH);
		OnFree2d(m_inImageB, m_inH);
		m_inImageR = m_inImageG = m_inImageB = NULL;
		m_inH = m_inW = 0;

		OnFree2d(m_outImageR, m_outH);
		OnFree2d(m_outImageG, m_outH);
		OnFree2d(m_outImageB, m_outH);
		m_outImageR = m_outImageG = m_outImageB = NULL;
		m_outH = m_outW = 0;
	}

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.
	CImage image;
	image.Load(lpszPathName);
	// (중요!) 입력 영상 크기 알아내기~
	m_inH = image.GetHeight();
	m_inW = image.GetWidth();
	// 메모리 할당
	m_inImageR = OnMalloc2D(m_inH, m_inW);
	m_inImageG = OnMalloc2D(m_inH, m_inW);
	m_inImageB = OnMalloc2D(m_inH, m_inW);
	// CImage의 객체값 --> 메모리
	COLORREF  px;
	for (int i=0; i<m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			px = image.GetPixel(k, i);
			m_inImageR[i][k] = GetRValue(px);
			m_inImageG[i][k] = GetGValue(px);
			m_inImageB[i][k] = GetBValue(px);
		}

	return TRUE;
}


unsigned char** CColorImageAlpha1Doc::OnMalloc2D(int h, int w)
{
	// TODO: 여기에 구현 코드 추가.
	unsigned char** memory;
	memory = new unsigned char* [h];
	for (int i = 0; i < h; i++)
		memory[i] = new unsigned char[w];
	return memory;
}


void CColorImageAlpha1Doc::OnFree2d(unsigned char** memory, int h)
{
	// TODO: 여기에 구현 코드 추가.
	if (memory == NULL)
		return;
	for (int i = 0; i < h; i++)
		delete memory[i];
	delete[] memory;
}


void CColorImageAlpha1Doc::OnCloseDocument()
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	OnFree2d(m_inImageR, m_inH);
	OnFree2d(m_inImageG, m_inH);
	OnFree2d(m_inImageB, m_inH);

	OnFree2d(m_outImageR, m_outH);
	OnFree2d(m_outImageG, m_outH);
	OnFree2d(m_outImageB, m_outH);

	OnFree2d(m_effectImageR, m_effectH);
	OnFree2d(m_effectImageG, m_effectH);
	OnFree2d(m_effectImageB, m_effectH);

	CDocument::OnCloseDocument();
}


void CColorImageAlpha1Doc::OnFreeOutImage()
{
	// TODO: 여기에 구현 코드 추가.
	if (m_outImageR != NULL) {
		OnFree2d(m_outImageR, m_outH);
		OnFree2d(m_outImageG, m_outH);
		OnFree2d(m_outImageB, m_outH);
		m_outImageR = m_outImageG = m_outImageB = NULL;
		m_outH = m_outW = 0;
	}
}

void CColorImageAlpha1Doc::OnEqualImage()
{

	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = m_inImageR[i][k];
			m_outImageG[i][k] = m_inImageG[i][k];
			m_outImageB[i][k] = m_inImageB[i][k];
		}
	}

}




void CColorImageAlpha1Doc::OnGrayScale()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	double avg;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
			m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char) avg;
		}
	}
}


BOOL CColorImageAlpha1Doc::OnSaveDocument(LPCTSTR lpszPathName)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if (m_outImageR == NULL)
		return FALSE;
	CImage image;
	image.Create(m_outW, m_outH, 32);
	unsigned char R, G, B;
	COLORREF px;
	for(int i=0; i<m_outW; i++) 
		for (int k = 0; k < m_outH; k++) {
			R = m_outImageR[k][i];
			G = m_outImageG[k][i];
			B = m_outImageB[k][i];
			px = RGB(R, G, B);
			image.SetPixel(i, k, px);
		}
	image.Save(lpszPathName, Gdiplus::ImageFormatPNG);
	MessageBox(NULL, L"저장", L"성공", NULL);
	return TRUE;
}


void CColorImageAlpha1Doc::OnAdderImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] + (int)dlg.m_constant;
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if(R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = m_inImageG[i][k] + (int)dlg.m_constant;
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = m_inImageB[i][k] + (int)dlg.m_constant;
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnInverseImage()
{
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = 255 - m_inImageR[i][k];
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = 255 - m_inImageG[i][k];
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = 255 - m_inImageB[i][k];
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}


void CColorImageAlpha1Doc::OnBinization128Image()
{
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int med = 128;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] ;
				if (R > med)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = 0;
				G = m_inImageG[i][k];
				if (G > med)
					m_outImageG[i][k] = 255;
				else 
					m_outImageG[i][k] = 0;
				B = m_inImageB[i][k];
				if (B > med)
					m_outImageB[i][k] = 255;
				else 
					m_outImageB[i][k] = 0;

			}
		}
	}


void CColorImageAlpha1Doc::OnBinizationavgImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	int R, G, B;
	// 이미지 픽셀 평균값 출력
	int sum = 0;
	double medR ,medG, medB, sumR, sumG, sumB ;
	medR = medG = medB = 0;
	sumR = sumG = sumB = 0;
	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			sumR += m_inImageR[i][k];
		}
	}
	medR = sumR / (m_inH * m_inW);

	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			sumG += m_inImageG[i][k];
		}
	}
	medG = sumG / (m_inH * m_inW);

	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			sumB += m_inImageB[i][k];
		}
	}
	medB = sumB / (m_inH * m_inW);
	// TODO: 여기에 구현 코드 추가.
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			R = m_inImageR[i][k];
			if (R > medR)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = 0;
			G = m_inImageG[i][k];
			if (G > medG)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = 0;
			B = m_inImageB[i][k];
			if (B > medB)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = 0;

		}
	}
}

/*  잘못만든 함수!!!!*/
int CColorImageAlpha1Doc::OnMediumVal()
{
	// TODO: 여기에 구현 코드 추가.
	return 0;
}


void CColorImageAlpha1Doc::OnBinizationmidImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	int R, G, B;
	// 이미지 픽셀 평균값 출력

	double medR, medG, medB;

	medR = medG =  medB = 0;

	unsigned char* onescale = new unsigned char[m_inH * m_inW]; // 1차원 동적 배열
	int count = 0;
	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			onescale[count] = m_inImageR[i][k];
			count++;
		}
	}
	// 오름차순 정렬을 위해 퀵정렬
	OnQuickSort(onescale, 0, (m_inH * m_inW) - 1);
	medR = (double)onescale[(int)(m_inH * m_inW / 2)];
	count = 0;
	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			onescale[count] = m_inImageG[i][k];
			count++;
		}

	}
	// 오름차순 정렬을 위해 퀵정렬
	OnQuickSort(onescale, 0, (m_inH * m_inW) - 1);
	medG = (double)onescale[(int)(m_inH * m_inW / 2)];
	count = 0;
	for (int i = 0; i < m_inH; i++)
	{
		for (int k = 0; k < m_inW; k++)
		{
			onescale[count] = m_inImageB[i][k];
			count++;
		}

	}
	// 오름차순 정렬을 위해 퀵정렬
	OnQuickSort(onescale, 0, (m_inH * m_inW) - 1);
	medB = (double)onescale[(int)(m_inH * m_inW / 2)];

	// TODO: 여기에 구현 코드 추가.
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			R = m_inImageR[i][k];
			if (R > medR)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = 0;
			G = m_inImageG[i][k];
			if (G > medG)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = 0;
			B = m_inImageB[i][k];
			if (B > medB)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = 0;

		}
	}
	delete[] onescale;
}


void CColorImageAlpha1Doc::OnQuickSort(unsigned char*& arr, int L, int R)
{
	// TODO: 여기에 구현 코드 추가
	int left = L, right = R;
	unsigned char pivot = arr[(L + R) / 2];
	unsigned char temp = 0;
	do
	{
		while (arr[left] < pivot)
			left++;
		while (arr[right] > pivot)
			right--;
		if (left <= right)
		{
			temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;
			left++;
			right--;
		}
	} while (left <= right);
	if (L < right)
		OnQuickSort(arr, L, right);

	if (left < R)
		OnQuickSort(arr, left, R);
}


void CColorImageAlpha1Doc::OnPosterImage()
{
	CPosterDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int level = dlg.m_posterlevel;
		// 이미지 포스터라이징(입력된 값을 라이징 값으로 입력받음)
		for (int i = 0; i < m_inH; i++)
		{
			for (int k = 0; k < m_inW; k++)
			{
				for (int m = 1; m <= level; m++)
				{
					if (m_inImageR[i][k] - ((255 / level) * m) <= 0)
					{
						m_outImageR[i][k] = ((255 / level) * (m-1));
						break;
					}
				}
			}
		}
		for (int i = 0; i < m_inH; i++)
		{
			for (int k = 0; k < m_inW; k++)
			{
				for (int m = 1; m <= level; m++)
				{
					if (m_inImageG[i][k] - ((255 / level) * m) <= 0)
					{
						m_outImageG[i][k] = ((255 / level) * (m - 1));
						break;
					}
				}
			}
		}
		for (int i = 0; i < m_inH; i++)
		{
			for (int k = 0; k < m_inW; k++)
			{
				for (int m = 1; m <= level; m++)
				{
					if (m_inImageB[i][k] - ((255 / level) * m) <= 0)
					{
						m_outImageB[i][k] = ((255 / level) * (m - 1));
						break;
					}
				}
			}
		}
	}
}


void CColorImageAlpha1Doc::OnAndbitImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int constant = abs(dlg.m_constant);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] & (int)constant;
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = m_inImageG[i][k] & (int)constant;
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = m_inImageB[i][k] & (int)constant;
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnOrbitImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int constant = abs(dlg.m_constant);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] | (int)constant;
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = m_inImageG[i][k] | (int)constant;
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = m_inImageB[i][k] | (int)constant;
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnXorbitImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int constant = abs(dlg.m_constant);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] ^ (int)constant;
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = m_inImageG[i][k] ^ (int)constant;
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = m_inImageB[i][k] ^ (int)constant;
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnMulImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int constant = abs(dlg.m_constant);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = m_inImageR[i][k] * (int)constant;
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = R;
				G = m_inImageG[i][k] * (int)constant;
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = G;
				B = m_inImageB[i][k] * (int)constant;
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnDivImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		int constant = abs(dlg.m_constant);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = (m_inImageR[i][k] / (int)constant);
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = (int)R;
				G = (m_inImageG[i][k] / (int)constant);
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = (int)G;
				B = (m_inImageB[i][k] / (int)constant);
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = (int)B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnParabolacapImage()
{
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	int R, G, B;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			R = 255.f * pow(m_inImageR[i][k] / 127.0 - 1.0, 2.0);
			if (R > 255)
				m_outImageR[i][k] = 255;
			else if (R < 0)
				m_outImageR[i][k] = 0;
			else
				m_outImageR[i][k] = (int)R;
			G = 255.f * pow(m_inImageG[i][k] / 127.0 - 1.0, 2.0);
			if (G > 255)
				m_outImageG[i][k] = 255;
			else if (G < 0)
				m_outImageG[i][k] = 0;
			else
				m_outImageG[i][k] = (int)G;
			B = 255.f * pow(m_inImageB[i][k] / 127.0 - 1.0, 2.0);
			if (B > 255)
				m_outImageB[i][k] = 255;
			else if (B < 0)
				m_outImageB[i][k] = 0;
			else
				m_outImageB[i][k] = (int)B;
		}
	}
}


void CColorImageAlpha1Doc::OnParabolacupImage()
{
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	int R, G, B;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			R = 255.0 - 255.0 * pow(m_inImageR[i][k] / 127.0 - 1.0, 2.0);
			if (R > 255)
				m_outImageR[i][k] = 255;
			else if (R < 0)
				m_outImageR[i][k] = 0;
			else
				m_outImageR[i][k] = (int)R;
			G = 255.0 - 255.0 * pow(m_inImageG[i][k] / 127.0 - 1.0, 2.0);
			if (G > 255)
				m_outImageG[i][k] = 255;
			else if (G < 0)
				m_outImageG[i][k] = 0;
			else
				m_outImageG[i][k] = (int)G;
			B = 255.0 - 255.0 * pow(m_inImageB[i][k] / 127.0 - 1.0, 2.0);
			if (B > 255)
				m_outImageB[i][k] = 255;
			else if (B < 0)
				m_outImageB[i][k] = 0;
			else
				m_outImageB[i][k] = (int)B;
		}
	}
}


void CColorImageAlpha1Doc::OnGammaImage()
{
	CGammaDlg dlg;
	if (dlg.DoModal() == IDOK) {
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int R, G, B;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				R = 255.0 * pow(((double)m_inImageR[i][k] / 255.0), (double)dlg.m_gamma);
				if (R > 255)
					m_outImageR[i][k] = 255;
				else if (R < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = (int)R;
				G = 255.0 * pow(((double)m_inImageG[i][k] / 255.0), (double)dlg.m_gamma);
				if (G > 255)
					m_outImageG[i][k] = 255;
				else if (G < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = (int)G;
				B = 255.0 * pow(((double)m_inImageB[i][k] / 255.0), (double)dlg.m_gamma);
				if (B > 255)
					m_outImageB[i][k] = 255;
				else if (B < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = (int)B;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnBlurImage()
{
	// TODO: 여기에 구현 코드 추가.
	CMaskscaleDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int maskscale = dlg.m_maskscale;
		if (maskscale % 2 == 0)
			maskscale++;
		double** mask = OnMallocDouble2D(maskscale, maskscale);

		for (int i = 0; i < maskscale; i++)
			for (int k = 0; k < maskscale; k++) {
				mask[i][k] = 1 / pow((double)maskscale, 2.0);
			}

		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (maskscale - 1); i++)
			for (int k = 0; k < m_inW + (maskscale - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageB[i][k];
			}
		double SR,SG,SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < maskscale; m++)
					for (int n = 0; n < maskscale; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
					}
				tmpoutImageR[i][k] = SR;
				tmpoutImageG[i][k] = SG;
				tmpoutImageB[i][k] = SB;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심
		OnFreeDouble2D(mask, maskscale);

		OnFreeDouble2D(tmpInImageR, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


double** CColorImageAlpha1Doc::OnMallocDouble2D(int h, int w)
{
	// TODO: 여기에 구현 코드 추가.
	double** memory;
	memory = new double* [h];
	for (int i = 0; i < h; i++)
		memory[i] = new double[w];
	return memory;
}


void CColorImageAlpha1Doc::OnFreeDouble2D(double** memory, int h)
{
	// TODO: 여기에 구현 코드 추가.
	if (memory == NULL)
		return;
	for (int i = 0; i < h; i++)
		delete memory[i];
	delete[] memory;
}


void CColorImageAlpha1Doc::OnSharpImage()
{
	CSharpmaskDlg dlg;
	if (dlg.DoModal() == IDOK) {
		double mask[3][3] = { 0, };
		double mask1[3][3] = { {-1.0, -1.0, -1.0}, // 샤프 마스크2
						  { -1.0, 9.0, -1.0},
						  { -1.0, -1.0, -1.0} };

		double mask2[3][3] = { {0.0, -1.0, 0.0}, // 샤프 마스크1 
							  { -1.0, 5.0, -1.0},
							  { 0.0, -1.0, 0.0} };
		int checkmask = 0;

		if (dlg.m_sharpmask == 1) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++)
					mask[i][k] = mask1[i][k];
		}
		else if (dlg.m_sharpmask == 2) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++)
					mask[i][k] = mask2[i][k];
		}
		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (3 - 1); i++)
			for (int k = 0; k < m_inW + (3 - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < 3; m++)
					for (int n = 0; n < 3; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
					}
				tmpoutImageR[i][k] = SR;
				tmpoutImageG[i][k] = SG;
				tmpoutImageB[i][k] = SB;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
	// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심

		OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnEmbossImage()
{
	double mask[3][3] = { {-1.0, 0.0, 0.0}, // 엠보싱 마스크
					  { 0.0, 0.0, 0.0},
					  { 0.0, 0.0, 1.0} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}

	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnGaussImage()
{
	double mask[3][3] = { {1.0 / 16, 1.0 / 8, 1.0 / 16}, // 엠보싱 마스크
						  { 1.0 / 8, 1.0 / 4, 1.0 / 8},
						  { 1.0 / 16, 1.0 / 8, 1.0 / 16} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}

	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnHighsharpImage()
{
	double mask[3][3] = { {-1.0/9, -1.0/9, -1.0/9 }, // 샤프 마스크2
					  { -1.0/9 , 8.0/9 , -1.0/9 },
					  { -1.0/9 , -1.0/9 , -1.0/9 } };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}

	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}
	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnLowsharpImage()
{
	CLowsharpDlg dlg;
	if (dlg.DoModal() == IDOK) {
		double mask[3][3] = { {1.0 / 9 , 1.0 / 9, 1.0 / 9 }, // 샤프 마스크2
						  { 1.0 / 9, 1.0 / 9, 1.0 / 9},
						  { 1.0 / 9, 1.0 / 9 , 1.0 / 9} };
		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (3 - 1); i++)
			for (int k = 0; k < m_inW + (3 - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < 3; m++)
					for (int n = 0; n < 3; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
					}
				tmpoutImageR[i][k] = m_inImageR[i][k] + dlg.m_alpha * ((double)m_inImageR[i][k] - SR);
				tmpoutImageG[i][k] = m_inImageG[i][k] + dlg.m_alpha * ((double)m_inImageG[i][k] - SG);
				tmpoutImageB[i][k] = m_inImageB[i][k] + dlg.m_alpha * ((double)m_inImageB[i][k] - SB);
			}
		}
		// 후처리 (마스크 값의 합계에 따라서...)
	// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심

		OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnChangeSatur()
{
	CChsaturDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		double H, S, I;
		unsigned char R, G, B;
		// ** 진짜 영상처리 알고리즘 **
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {

				// HIS 모델 값
				// H(색상) : 0 ~ 360
				// S(채도) : 0.0 ~ 1.0
				// I(명도) : 0 ~ 255

				// RGB --> HSI
				R = m_inImageR[i][k];
				G = m_inImageG[i][k];
				B = m_inImageB[i][k];

				double* hsi = RGB2HSI(R, G, B);
				H = hsi[0];
				S = hsi[1];
				I = hsi[2];

				// 채도(S) 흐리게
				S = S + dlg.m_satur;
				if (S < 0)
					S = 0.0;
				if (S > 1)
					S = 1.0;
				// HSI --> RGB

				unsigned char* rgb = HSI2RGB(H, S, I);
				R = rgb[0]; G = rgb[1];	B = rgb[2];

				m_outImageR[i][k] = R;
				m_outImageG[i][k] = G;
				m_outImageB[i][k] = B;


			}
		}
	}
}


double* CColorImageAlpha1Doc::RGB2HSI(int R, int G, int B)
{
	// TODO: 여기에 구현 코드 추가.
	double H, S, I;
	double* HSI = new double[3];
	double min_value, angle;
	I = (R + G + B) / 3.0; // 밝기
	if ((R == G) && (G == B)) { // 그레이
		S = 0.0;
		H = 0.0;
	}
	else {

		min_value = min(min(R, G), B); //최소값 추출
		angle = (R - 0.5 * G - 0.5 * B) / (double)sqrt((R - G) * (R - G) + (R - B) * (G - B));

		H = (double)acos(angle) * 57.29577951;
		S = 1.0f - (3.0 / (R + G + B)) * min_value;
	}
	if (B > G) H = 360. - H;

	HSI[0] = H;
	HSI[1] = S;
	HSI[2] = I;

	return HSI;
}


unsigned char* CColorImageAlpha1Doc::HSI2RGB(double H, double S, double I)
{
	// TODO: 여기에 구현 코드 추가.
	double R, G, B;
	unsigned char* RGB = new unsigned char[3];
	double angle1, angle2, scale;

	if (I == 0.0) { // Black
		RGB[0] = 0;
		RGB[1] = 0;
		RGB[2] = 0;
		return RGB;
	}

	if (H <= 0.0) H += 360.0f;

	scale = 3.0 * I;
	if (H <= 120.0)
	{
		angle1 = H * 0.017453293;
		angle2 = (60.0 - H) * 0.017453293;
		B = (1.0 - S) / 3.0f;
		R = (double)(1.0 + (S * cos(angle1) / cos(angle2))) / 3.0;
		G = 1.0 - R - B;
		B *= scale;
		R *= scale;
		G *= scale;
	}


	else if ((H > 120.0) && (H <= 240.0)) {
		H -= 120.0;
		angle1 = H * 0.017453293;

		angle2 = (60.0 - H) * 0.017453293;
		R = (1.0 - S) / 3.0;
		G = (double)(1.0f + (S * cos(angle1) / cos(angle2))) / 3.0;
		B = 1.0 - R - G;
		R *= scale;
		G *= scale;
		B *= scale;
	}
	else {
		H -= 240.0;
		angle1 = H * 0.017453293;
		angle2 = (60.0 - H) * 0.017453293;
		G = (1.0f - S) / 3.0;
		B = (double)(1.0 + (S * cos(angle1) / cos(angle2))) / 3.0;
		R = 1.0 - G - B;

		R *= scale;
		G *= scale;
		B *= scale;
	}

	RGB[0] = (unsigned char)R;
	RGB[1] = (unsigned char)G;
	RGB[2] = (unsigned char)B;
	return RGB;
}


void CColorImageAlpha1Doc::OnPickorangeImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	double H, S, I;
	unsigned char R, G, B;
	// ** 진짜 영상처리 알고리즘 **
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {

			// HIS 모델 값
			// H(색상) : 0 ~ 360
			// S(채도) : 0.0 ~ 1.0
			// I(명도) : 0 ~ 255

			// RGB --> HSI
			R = m_inImageR[i][k];
			G = m_inImageG[i][k];
			B = m_inImageB[i][k];

			double* hsi = RGB2HSI(R, G, B);
			H = hsi[0];
			S = hsi[1];
			I = hsi[2];

			// 오렌지 추출 ( H : 8~20)
			if (8 <= H && H <= 20) {

				m_outImageR[i][k] = m_inImageR[i][k];
				m_outImageG[i][k] = m_inImageG[i][k];
				m_outImageB[i][k] = m_inImageB[i][k];

			}
			else {
				double avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
				m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;
			}

		}
	}
}


void CColorImageAlpha1Doc::OnForwardreductImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int scale = dlg.m_constant;
		// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH / scale)+1;
		m_outW = (int)(m_inW / scale)+1;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				m_outImageR[(int)(i / scale)][(int)(k / scale)] = m_inImageR[i][k];
				m_outImageG[(int)(i / scale)][(int)(k / scale)] = m_inImageG[i][k];
				m_outImageB[(int)(i / scale)][(int)(k / scale)] = m_inImageB[i][k];
			}
		}
	}
}


void CColorImageAlpha1Doc::OnForwardmedreductImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int scale = dlg.m_constant;
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH / scale)+1;
		m_outW = (int)(m_inW / scale)+1;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		int sumR, sumG, sumB;
		int medR, medG, medB;
		medR = medG = medB =0;
		sumR = sumG = sumB = 0;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				sumR = sumG = sumB= 0;
				medR = medG = medB = 0;
				for (int a = i; a < i + scale; a++) {
					for (int b = k; b < k + scale; b++) {
						if ((0 <= a && a < m_inH) && (0 <= b && b < m_inW)) {
							sumR += m_inImageR[a][b];
							sumG += m_inImageG[a][b];
							sumB += m_inImageB[a][b];
						}
					}
				}
				medR = (int)(sumR / (scale * scale));
				medG = (int)(sumG / (scale * scale));
				medB = (int)(sumB / (scale * scale));

				m_outImageR[(int)(i / scale)][(int)(k / scale)] = (unsigned char)medR;
				m_outImageG[(int)(i / scale)][(int)(k / scale)] = (unsigned char)medG;
				m_outImageB[(int)(i / scale)][(int)(k / scale)] = (unsigned char)medB;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnForwardmidreductImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
			int scale = dlg.m_constant;
			// TODO: 여기에 구현 코드 추가.
			// 기존 메모리 해제
			OnFreeOutImage();
			// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
			m_outH = (int)(m_inH / scale)+1;
			m_outW = (int)(m_inW / scale)+1;
			// 메모리 할당
			m_outImageR = OnMalloc2D(m_outH, m_outW);
			m_outImageG = OnMalloc2D(m_outH, m_outW);
			m_outImageB = OnMalloc2D(m_outH, m_outW);
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				int temp_index = 0;
				unsigned char* tempR;
				unsigned char* tempG;
				unsigned char* tempB;
				tempR = new unsigned char[pow(scale, 2)];
				tempG = new unsigned char[pow(scale, 2)];
				tempB = new unsigned char[pow(scale, 2)];
				temp_index = 0;
				for (int a = i; a < scale + i; a++) {
					for (int b = k; b < scale + k; b++) {
						if ((0 <= a && a < m_inH) && (0 <= b && b < m_inW)) {
							tempR[temp_index] = m_inImageR[a][b];
							tempG[temp_index] = m_inImageG[a][b];
							tempB[temp_index] = m_inImageB[a][b];
							temp_index++;
						}
					}
				}

				OnQuickSort(tempR, 0, (int)pow(scale, 2) - 1);
				OnQuickSort(tempG, 0, (int)pow(scale, 2) - 1);
				OnQuickSort(tempB, 0, (int)pow(scale, 2) - 1);

				m_outImageR[(int)(i / scale)][(int)(k / scale)] = tempR[(int)(pow(scale, 2) / 2)];
				m_outImageG[(int)(i / scale)][(int)(k / scale)] = tempG[(int)(pow(scale, 2) / 2)];
				m_outImageB[(int)(i / scale)][(int)(k / scale)] = tempB[(int)(pow(scale, 2) / 2)];
			
				delete[] tempR;
				delete[] tempG;
				delete[] tempB;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnForwardenlargeImage()
{
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int scale = dlg.m_constant;
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH * scale);
		m_outW = (int)(m_inW * scale);
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// 메모리 할당
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				m_outImageR[(int)(i * scale)][(int)(k * scale)] = m_inImageR[i][k];
				m_outImageG[(int)(i * scale)][(int)(k * scale)] = m_inImageG[i][k];
				m_outImageB[(int)(i * scale)][(int)(k * scale)] = m_inImageB[i][k];
			}
		}

	}
}


void CColorImageAlpha1Doc::OnBackwardenlargeImage()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int scale = dlg.m_constant;
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH * scale);
		m_outW = (int)(m_inW * scale);
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				m_outImageR[i][k] = m_inImageR[(int)(i / scale)][(int)(k / scale)];
				m_outImageG[i][k] = m_inImageG[(int)(i / scale)][(int)(k / scale)];
				m_outImageB[i][k] = m_inImageB[(int)(i / scale)][(int)(k / scale)];
			}
		}

	}
}


void CColorImageAlpha1Doc::OnBackwardenlargeboganImage()
{
	// TODO: 여기에 구현 코드 추가.
	CConstantDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int scale = dlg.m_constant;
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH * scale);
		m_outW = (int)(m_inW * scale);
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		int i_H, i_W;
		unsigned char newValueR, newValueG, newValueB;
		double r_H, r_W, s_H, s_W;
		double C1R, C2R, C3R, C4R, C1G, C2G, C3G, C4G, C1B, C2B, C3B, C4B;
		// 입력 배열 --> 출력 배열

		for (int i = 0; i < m_outH; i++) {
			for (int j = 0; j < m_outW; j++) {
				r_H = i / scale;
				r_W = j / scale;
				i_H = (int)floor(r_H);
				i_W = (int)floor(r_W);
				s_H = r_H - i_H;
				s_W = r_W - i_W;
				if (i_H < 0 || i_H >= (m_inH - 1) || i_W < 0
					|| i_W >= (m_inW - 1))
				{
					m_outImageR[i][j] = 255;
				}
				else
				{
					C1R = (double)m_inImageR[i_H][i_W];
					C2R = (double)m_inImageR[i_H][i_W + 1];
					C3R = (double)m_inImageR[i_H + 1][i_W + 1];
					C4R = (double)m_inImageR[i_H + 1][i_W];
					C1G = (double)m_inImageG[i_H][i_W];
					C2G = (double)m_inImageG[i_H][i_W + 1];
					C3G = (double)m_inImageG[i_H + 1][i_W + 1];
					C4G = (double)m_inImageG[i_H + 1][i_W];
					C1B = (double)m_inImageB[i_H][i_W];
					C2B = (double)m_inImageB[i_H][i_W + 1];
					C3B = (double)m_inImageB[i_H + 1][i_W + 1];
					C4B = (double)m_inImageB[i_H + 1][i_W];
					newValueR = (unsigned char)(C1R * (1 - s_H) * (1 - s_W) + C2R * s_W * (1 - s_H) + C3R * s_W * s_H + C4R * (1 - s_W) * s_H);
					newValueG = (unsigned char)(C1G * (1 - s_H) * (1 - s_W) + C2G * s_W * (1 - s_H) + C3G * s_W * s_H + C4G * (1 - s_W) * s_H);
					newValueB = (unsigned char)(C1B * (1 - s_H) * (1 - s_W) + C2B * s_W * (1 - s_H) + C3B * s_W * s_H + C4B * (1 - s_W) * s_H);
					if (newValueR > 255)
						m_outImageR[i][j] = 255;
					else if (newValueR < 0)
						m_outImageR[i][j] = 0;
					else
						m_outImageR[i][j] = newValueR;
					if (newValueG > 255)
						m_outImageG[i][j] = 255;
					else if (newValueG < 0)
						m_outImageG[i][j] = 0;
					else
						m_outImageG[i][j] = newValueG;
					if (newValueB > 255)
						m_outImageB[i][j] = 255;
					else if (newValueB < 0)
						m_outImageB[i][j] = 0;
					else
						m_outImageB[i][j] = newValueB;
				}
			}
		}
	}
}




void CColorImageAlpha1Doc::OnForwardrotateImage()
{
	CRotateDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH);
		m_outW = (int)(m_inW);
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double degree = dlg.m_degree;
		double radian = degree * 3.141592 / 180.0;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				int xd = (int)(cos(radian) * i - sin(radian) * k);
				int yd = (int)(sin(radian) * i + cos(radian) * k);

				if ((0 <= xd && xd < m_outH) && (0 <= yd && yd < m_outW)) {
					m_outImageR[xd][yd] = m_inImageR[i][k];
					m_outImageG[xd][yd] = m_inImageG[i][k];
					m_outImageB[xd][yd] = m_inImageB[i][k];

				}
			}
		}
	}
}


void CColorImageAlpha1Doc::OnBackwardrotateImage()
{
	CRotateDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = (int)(m_inH);
		m_outW = (int)(m_inW);
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double degree = dlg.m_degree;
		double radian = degree * 3.141592 / 180.0;
		// xd = cos*(xs) - sin*(ys)
		// yd = sin*(xs) + cos*(ys)
		// 입력 배열 --> 출력 배열

		// 입력 영상의 각 픽셀을 중앙으로 시킨후 회전을 시키기 위한 중앙 위치 값
		int cx = m_inH / 2;
		int cy = m_inW / 2;

		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				int xs = (int)(cos(radian) * (i - cx) + sin(radian) * (k - cy));
				int ys = (int)(-sin(radian) * (i - cx) + cos(radian) * (k - cy));
				xs += cx;
				ys += cy;

				if ((0 <= xs && xs < m_outH) && (0 <= ys && ys < m_outW)) {
					m_outImageR[i][k] = m_inImageR[xs][ys];
					m_outImageG[i][k] = m_inImageG[xs][ys];
					m_outImageB[i][k] = m_inImageB[xs][ys];
				}

			}
		}
	}
}


void CColorImageAlpha1Doc::OnEnlargerotateImage()
{
	CRotateDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		double degree = dlg.m_degree;
		double radian = degree * 3.141592 / 180.0;

		m_outW = (int)(m_inH * fabs(cos((double)((double)(90 - degree) * 3.141592 / 180.0))) + m_inW * fabs(cos(radian)));
		m_outH = (int)(m_inW * fabs(cos((double)((double)(90 - degree) * 3.141592 / 180.0))) + m_inH * fabs(cos(radian)));
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		// xd = cos*(xs) - sin*(ys)
		// yd = sin*(xs) + cos*(ys)
		// 입력 배열 --> 출력 배열

		// 입력 영상의 각 픽셀을 중앙으로 시킨후 회전을 시키기 위한 중앙 위치 값

		int cx = (int)m_inH / 2;
		int cy = (int)m_inW / 2;

		// 중앙을 기준으로 실제 출력 영상에서 위치를 맞춰주기 위한 값
		int cx2 = (int)m_outH / 2;
		int cy2 = (int)m_outW / 2;
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				int xd = i;
				int yd = k;

				int xs = (int)(cos(radian) * (xd - cx2) + sin(radian) * (yd - cy2));
				int ys = (int)(-sin(radian) * (xd - cx2) + cos(radian) * (yd - cy2));

				xs += cx;
				ys += cy;

				if ((0 <= xs && xs < m_inH) && (0 <= ys && ys < m_inW)) {
					m_outImageR[xd][yd] = m_inImageR[xs][ys];
					m_outImageG[xd][yd] = m_inImageG[xs][ys];
					m_outImageB[xd][yd] = m_inImageB[xs][ys];
				}
				else {
					m_outImageR[xd][yd] = 255;
					m_outImageG[xd][yd] = 255;
					m_outImageB[xd][yd] = 255;
				}
			}
		}
	}
}


void CColorImageAlpha1Doc::OnEnlargeboganrotateImage()
{
	CRotateDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		double degree = dlg.m_degree;
		double radian = degree * 3.141592 / 180.0;

		m_outW = (int)(m_inH * fabs(cos((double)((double)(90 - degree) * 3.141592 / 180.0))) + m_inW * fabs(cos(radian)));
		m_outH = (int)(m_inW * fabs(cos((double)((double)(90 - degree) * 3.141592 / 180.0))) + m_inH * fabs(cos(radian)));
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		// xd = cos*(xs) - sin*(ys)
		// yd = sin*(xs) + cos*(ys)
		// 입력 배열 --> 출력 배열

		double scale_W = (double)(m_outW / m_inW);
		double scale_H = (double)(m_outH / m_inH);

		// 입력 영상을 중앙으로 이동시키기 위한 값
		int cx = (int)m_inH / 2;
		int cy = (int)m_inW / 2;

		// 중앙을 기준으로 실제 출력 영상에서 위치를 맞춰주기 위한 값
		int cx2 = (int)m_outH / 2;
		int cy2 = (int)m_outW / 2;

		int i_H, i_W;
		unsigned char newValueR, newValueG, newValueB;
		double r_H, r_W, s_H, s_W;
		double C1R, C2R, C3R, C4R, C1G, C2G, C3G, C4G, C1B, C2B, C3B, C4B;
		int xs1 = 0, xs2 = 0, xs3 = 0, xs4 = 0, ys1 = 0, ys2 = 0, ys3 = 0, ys4 = 0;
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {

				r_H = i / scale_H;
				r_W = k / scale_W;
				i_H = (int)floor(r_H);
				i_W = (int)floor(r_W);
				s_H = r_H - i_H;
				s_W = r_W - i_W;
				if (i_H < 0 || i_H >= (m_inH - 1) || i_W < 0
					|| i_W >= (m_inW - 1))
				{
					m_outImageR[i][k] = 255;
					m_outImageG[i][k] = 255;
					m_outImageB[i][k] = 255;
				}
				int xd = i;
				int yd = k;

				xs1 = (int)(cos(radian) * (xd - cx2) + sin(radian) * (yd - cy2));
				ys1 = (int)(-sin(radian) * (xd - cx2) + cos(radian) * (yd - cy2));

				xs2 = (int)(cos(radian) * (xd + 1 - cx2) + sin(radian) * (yd - cy2));
				ys2 = (int)(-sin(radian) * (xd + 1 - cx2) + cos(radian) * (yd - cy2));

				xs3 = (int)(cos(radian) * (xd - cx2) + sin(radian) * (yd + 1 - cy2));
				ys3 = (int)(-sin(radian) * (xd - cx2) + cos(radian) * (yd + 1 - cy2));

				xs4 = (int)(cos(radian) * (xd + 1 - cx2) + sin(radian) * (yd + 1 - cy2));
				ys4 = (int)(-sin(radian) * (xd + 1 - cx2) + cos(radian) * (yd + 1 - cy2));

				xs1 += cx;
				ys1 += cy;

				xs2 += cx;
				ys2 += cy;

				xs3 += cx;
				ys3 += cy;

				xs4 += cx;
				ys4 += cy;

				if ((0 <= xs1 && xs1 < m_inH) && (0 <= ys1 && ys1 < m_inW)) {
					C1R = (double)m_inImageR[xs1][ys1];
					C1G = (double)m_inImageG[xs1][ys1];
					C1B = (double)m_inImageB[xs1][ys1];
				}
				else {
					C1R = 255;
					C1G = 255;
					C1B = 255;
				}
				if ((0 <= xs2 && xs2 < m_inH) && (0 <= ys2 && ys2 < m_inW)) {
					C2R = (double)m_inImageR[xs2][ys2];
					C2G = (double)m_inImageG[xs2][ys2];
					C2B = (double)m_inImageB[xs2][ys2];
				}
				else {
					C2R = 255;
					C2G = 255;
					C2B = 255;
				}
				if ((0 <= xs3 && xs3 < m_inH) && (0 <= ys3 && ys3 < m_inW)) {
					C3R = (double)m_inImageR[xs3][ys3];
					C3G = (double)m_inImageG[xs3][ys3];
					C3B = (double)m_inImageB[xs3][ys3];
				}
				else {
					C3R = 255;
					C3G = 255;
					C3B = 255;
				}
				if ((0 <= xs4 && xs4 < m_inH) && (0 <= ys4 && ys4 < m_inW)) {
					C4R = (double)m_inImageR[xs4][ys4];
					C4G = (double)m_inImageG[xs4][ys4];
					C4B = (double)m_inImageB[xs4][ys4];
				}
				else {
					C4R = 255;
					C4G = 255;
					C4B = 255;
				}
				newValueR = (unsigned char)(C1R * (1 - s_H) * (1 - s_W) + C2R * s_W * (1 - s_H) + C4R * s_W * s_H + C3R * (1 - s_W) * s_H);
				newValueG = (unsigned char)(C1G * (1 - s_H) * (1 - s_W) + C2G * s_W * (1 - s_H) + C4G * s_W * s_H + C3G * (1 - s_W) * s_H);
				newValueB = (unsigned char)(C1B * (1 - s_H) * (1 - s_W) + C2B * s_W * (1 - s_H) + C4B * s_W * s_H + C3B * (1 - s_W) * s_H);
				if (newValueR > 255)
					m_outImageR[i][k] = 255;
				else if (newValueR < 0)
					m_outImageR[i][k] = 0;
				else
					m_outImageR[i][k] = newValueR;
				if (newValueG > 255)
					m_outImageG[i][k] = 255;
				else if (newValueG < 0)
					m_outImageG[i][k] = 0;
				else
					m_outImageG[i][k] = newValueG;
				if (newValueB > 255)
					m_outImageB[i][k] = 255;
				else if (newValueB < 0)
					m_outImageB[i][k] = 0;
				else
					m_outImageB[i][k] = newValueB;
			}
		}
	}
}


void CColorImageAlpha1Doc::OnMoveImage()
{
	CMoveimageDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		OnFreeOutImage();
		m_outImage = NULL;
		m_outH = m_outW = 0;

		m_outH = m_inH;
		m_outW = m_inW;

		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		int left = dlg.m_moveleft;

		int right = dlg.m_moveright;

		int up = dlg.m_moveup;

		int down = dlg.m_movedown;
		for (int i = 0; i < m_inH; i++) {
			int move_updown = i + up - down;
			for (int k = 0; k < m_inW; k++) {
				int move_side = k + left - right;
				if ((0 <= move_updown && move_updown < m_inH) && (0 <= move_side && move_side < m_inW)) {
					m_outImageR[i][k] = m_inImageR[move_updown][move_side];
					m_outImageG[i][k] = m_inImageG[move_updown][move_side];
					m_outImageB[i][k] = m_inImageB[move_updown][move_side];
				}
			}
		}
	}
}


void CColorImageAlpha1Doc::OnSymmetryImage()
{
	CSymmetryDlg dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		OnFreeOutImage();
		m_outImage = NULL;
		m_outH = m_outW = 0;

		m_outH = m_inH;
		m_outW = m_inW;

		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		int inKey = dlg.m_symmetry;
		switch (inKey) {
		case 1:
			for (int i = 0; i < m_inH; i++)
				for (int k = 0; k < m_inW; k++) {
					m_outImageR[i][k] = m_inImageR[i][m_inW - (k + 1)];
					m_outImageG[i][k] = m_inImageG[i][m_inW - (k + 1)];
					m_outImageB[i][k] = m_inImageB[i][m_inW - (k + 1)];
				}
			break;
		case 2:
			for (int i = 0; i < m_inH; i++)
				for (int k = 0; k < m_inW; k++) {
					m_outImageR[i][k] = m_inImageR[m_inH - (i + 1)][k];
					m_outImageG[i][k] = m_inImageG[m_inH - (i + 1)][k];
					m_outImageB[i][k] = m_inImageB[m_inH - (i + 1)][k];
				}
			break;
		case 3:
			for (int i = 0; i < m_inH; i++)
				for (int k = 0; k < m_inW; k++) {
					m_outImageR[i][k] = m_inImageR[m_inH - (i + 1)][m_inW - (k + 1)];
					m_outImageG[i][k] = m_inImageG[m_inH - (i + 1)][m_inW - (k + 1)];
					m_outImageB[i][k] = m_inImageB[m_inH - (i + 1)][m_inW - (k + 1)];
				}
			break;
		}
	}
}


void CColorImageAlpha1Doc::OnEndinImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 출력 메모리 해제
		// TODO: 여기에 구현 코드 추가.
	OnFreeOutImage();
	m_outImage = NULL;
	m_outH = m_outW = 0;

	m_outH = m_inH;
	m_outW = m_inW;

	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	int highR = m_inImageR[0][0], lowR = m_inImageR[0][0];
	int highG = m_inImageG[0][0], lowG = m_inImageG[0][0];
	int highB = m_inImageB[0][0], lowB = m_inImageB[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageR[i][k] < lowR) {
				lowR = m_inImageR[i][k];
			}
			if (m_inImageG[i][k] < lowG) {
				lowG = m_inImageG[i][k];
			}
			if (m_inImageB[i][k] < lowB) {
				lowB = m_inImageB[i][k];
			}
			if (m_inImageR[i][k] > highR) {
				highR = m_inImageR[i][k];
			}
			if (m_inImageG[i][k] > highG) {
				highG = m_inImageG[i][k];
			}
			if (m_inImageB[i][k] > highB) {
				highB = m_inImageB[i][k];
			}
		}
	}
	highR -= 50;
	lowR += 50;
	highG -= 50;
	lowG += 50;
	highB -= 50;
	lowB += 50;
	int oldR, valR, oldG, valG, oldB, valB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			oldR = m_inImageR[i][k];
			oldG = m_inImageG[i][k];
			oldB = m_inImageB[i][k];
			valR = (int)((double)(oldR - lowR) / (double)(highR - lowR) * 255.0);
			valG = (int)((double)(oldG - lowG) / (double)(highG - lowG) * 255.0);
			valB = (int)((double)(oldB - lowB) / (double)(highB - lowB) * 255.0);
			if (valR > 255)
				valR = 255;
			if (valR < 0)
				valR = 0;
			m_outImageR[i][k] = valR;
			if (valG > 255)
				valG = 255;
			if (valG < 0)
				valG = 0;
			m_outImageG[i][k] = valG;
			if (valB > 255)
				valB = 255;
			if (valB < 0)
				valB = 0;
			m_outImageB[i][k] = valB;
		}
	}
}


void CColorImageAlpha1Doc::OnDefaultstrechImage()
{
	OnFreeOutImage();
	m_outImage = NULL;
	m_outH = m_outW = 0;

	m_outH = m_inH;
	m_outW = m_inW;

	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// 진짜 영상처리 알고리즘
	// new = (old- low) / (high - low) * 255.0
	int highR = m_inImageR[0][0], lowR = m_inImageR[0][0];
	int highG = m_inImageG[0][0], lowG = m_inImageG[0][0];
	int highB = m_inImageB[0][0], lowB = m_inImageB[0][0];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			if (m_inImageR[i][k] < lowR) {
				lowR = m_inImageR[i][k];
			}
			if (m_inImageG[i][k] < lowG) {
				lowG = m_inImageG[i][k];
			}
			if (m_inImageB[i][k] < lowB) {
				lowB = m_inImageB[i][k];
			}
			if (m_inImageR[i][k] > highR) {
				highR = m_inImageR[i][k];
			}
			if (m_inImageG[i][k] > highG) {
				highG = m_inImageG[i][k];
			}
			if (m_inImageB[i][k] > highB) {
				highB = m_inImageB[i][k];
			}
		}
	}
	int oldR, valR, oldG, valG, oldB, valB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			oldR = m_inImageR[i][k];
			oldG = m_inImageG[i][k];
			oldB = m_inImageB[i][k];
			valR = (int)((double)(oldR - lowR) / (double)(highR - lowR) * 255.0);
			valG = (int)((double)(oldG - lowG) / (double)(highG - lowG) * 255.0);
			valB = (int)((double)(oldB - lowB) / (double)(highB - lowB) * 255.0);
			if (valR > 255)
				valR = 255;
			if (valR < 0)
				valR = 0;
			m_outImageR[i][k] = valR;
			if (valG > 255)
				valG = 255;
			if (valG < 0)
				valG = 0;
			m_outImageG[i][k] = valG;
			if (valB > 255)
				valB = 255;
			if (valB < 0)
				valB = 0;
			m_outImageB[i][k] = valB;
		}
	}
}


void CColorImageAlpha1Doc::OnHistosmoothImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 출력 메모리 해제
	OnFreeOutImage();
	m_outImage = NULL;
	m_outH = m_outW = 0;

	m_outH = m_inH;
	m_outW = m_inW;

	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// TODO: 여기에 구현 코드 추가.
	int histoR[256] = { 0, };
	int histoG[256] = { 0, };
	int histoB[256] = { 0, };
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			histoR[m_inImageR[i][k]]++;
			histoG[m_inImageG[i][k]]++;
			histoB[m_inImageB[i][k]]++;
		}
	}

	// 2단계 누적히스토그램 생성
	int sumHistoR[256] = { 0, };
	int sumHistoG[256] = { 0, };
	int sumHistoB[256] = { 0, };

	sumHistoR[0] = histoR[0];
	sumHistoG[0] = histoG[0];
	sumHistoB[0] = histoB[0];
	for (int i = 1; i < 256; i++) {
		sumHistoR[i] = sumHistoR[i - 1] + histoR[i];

		sumHistoG[i] = sumHistoG[i - 1] + histoG[i];

		sumHistoB[i] = sumHistoB[i - 1] + histoB[i];
	}

	// 3단계 정규화된 히스토그램 생성 nomalHisto = sumHist * (1.0/(inH*inW)) * 255.0)
	double normalHistoR[256] = { 1.0, };
	double normalHistoG[256] = { 1.0, };
	double normalHistoB[256] = { 1.0, };
	for (int i = 0; i < 256; i++) {
		normalHistoR[i] = sumHistoR[i] * (1.0 / (m_inH * m_inW)) * 255.0;
		normalHistoG[i] = sumHistoG[i] * (1.0 / (m_inH * m_inW)) * 255.0;
		normalHistoB[i] = sumHistoB[i] * (1.0 / (m_inH * m_inW)) * 255.0;

	}
	// 4단계 inImage를 정규화된 값으로 치환
	// 입력 배열 --> 출력 배열
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = (unsigned char)normalHistoR[m_inImageR[i][k]];
			m_outImageG[i][k] = (unsigned char)normalHistoG[m_inImageG[i][k]];
			m_outImageB[i][k] = (unsigned char)normalHistoB[m_inImageB[i][k]];
		}
	}
}


void CColorImageAlpha1Doc::OnEdgeverticalImage()
{
	double mask[3][3] = { {0.0, 0.0, 0.0}, // 수직 에지 마스크
					  { -1.0, 1.0, 0.0},
					  { 0.0, 0.0, 0.0} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}

	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnEdgehorizontalImage()
{
	double mask[3][3] = { {0.0, -1.0, 0.0}, // 수평 에지 마스크
				  { 0.0, 1.0, 0.0},
				  { 0.0, 0.0, 0.0} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 3; m++)
				for (int n = 0; n < 3; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}

	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}



void CColorImageAlpha1Doc::OnEdgehomogenImage()
{
	// TODO: 여기에 구현 코드 추가.
	CMaskscaleDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int maskscale = dlg.m_maskscale;
		if (maskscale % 2 == 0)
			maskscale++;
		double** mask = OnMallocDouble2D(maskscale, maskscale);

		for (int i = 0; i < maskscale; i++)
			for (int k = 0; k < maskscale; k++) {
				mask[i][k] = 1 / pow((double)maskscale, 2.0);
			}

		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (maskscale - 1); i++)
			for (int k = 0; k < m_inW + (maskscale - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		double maxoutR = 0.0;
		double maxoutG = 0.0;
		double maxoutB = 0.0;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				maxoutR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				maxoutG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				maxoutB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < (int)((int)(maskscale / 2)); m++) {
					for (int n = 0; n < (int)((int)(maskscale / 2)); n++) {
						//printf("%lf ", maxout);
						if (maxoutR <= fabs(tmpInImageR[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageR[i + m][k + n]))
							maxoutR = fabs(tmpInImageR[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageR[i + m][k + n]);
						if (maxoutG <= fabs(tmpInImageG[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageG[i + m][k + n]))
							maxoutG = fabs(tmpInImageG[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageG[i + m][k + n]);
						if (maxoutB <= fabs(tmpInImageB[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageB[i + m][k + n]))
							maxoutB = fabs(tmpInImageB[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] - tmpInImageB[i + m][k + n]);
					}
				}
				tmpoutImageR[i][k] = maxoutR;
				tmpoutImageG[i][k] = maxoutG;
				tmpoutImageB[i][k] = maxoutB;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심
		OnFreeDouble2D(mask, maskscale);

		OnFreeDouble2D(tmpInImageR, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnEdgesubImage()
{
	// TODO: 여기에 구현 코드 추가.
	CMaskscaleDlg dlg;
	if (dlg.DoModal() == IDOK) {
		int maskscale = dlg.m_maskscale;
		if (maskscale % 2 == 0)
			maskscale++;
		double** mask = OnMallocDouble2D(maskscale, maskscale);

		for (int i = 0; i < maskscale; i++)
			for (int k = 0; k < maskscale; k++) {
				mask[i][k] = 1 / pow((double)maskscale, 2.0);
			}

		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (maskscale - 1), m_inW + (maskscale - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (maskscale - 1); i++)
			for (int k = 0; k < m_inW + (maskscale - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(maskscale / 2)][k + (int)(maskscale / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		double maxoutR = 0.0;
		double maxoutG = 0.0;
		double maxoutB = 0.0;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				maxoutR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				maxoutG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				maxoutB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < (int)((int)(maskscale / 2)); m++) {
					for (int n = 0; n < (int)((int)(maskscale / 2)); n++) {
						//printf("%lf ", maxout);
						if (maxoutR <= fabs(tmpInImageR[i + m][k + n] - tmpInImageR[i + (maskscale - 1) - m][k + (maskscale - 1) - n]))
							maxoutR = fabs(tmpInImageR[i + m][k + n] - tmpInImageR[i + (maskscale - 1) - m][k + (maskscale - 1) - n]);
						if (maxoutG <= fabs(tmpInImageG[i + m][k + n] - tmpInImageG[i + (maskscale - 1) - m][k + (maskscale - 1) - n]))
							maxoutG = fabs(tmpInImageG[i + m][k + n] - tmpInImageG[i + (maskscale - 1) - m][k + (maskscale - 1) - n]);
						if (maxoutB <= fabs(tmpInImageB[i + m][k + n] - tmpInImageB[i + (maskscale - 1) - m][k + (maskscale - 1) - n]))
							maxoutB = fabs(tmpInImageB[i + m][k + n] - tmpInImageB[i + (maskscale - 1) - m][k + (maskscale - 1) - n]);
					}
				}
				tmpoutImageR[i][k] = maxoutR;
				tmpoutImageG[i][k] = maxoutG;
				tmpoutImageB[i][k] = maxoutB;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심
		OnFreeDouble2D(mask, maskscale);

		OnFreeDouble2D(tmpInImageR, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (maskscale - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnEdgefirstderivativeImage()
{
	CEdgefirstDlg dlg;

	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		double maskRobert_1[3][3] = { {-1.0, 0.0, 0.0}, // 로버츠 행 검출 마스크
						  { 0.0, 1.0, 0.0},
						  { 0.0, 0.0, 0.0} };

		double maskRobert_2[3][3] = { {0.0, 0.0, -1.0},  // 로버츠 열 검출 마스크 
							  { 0.0, 1.0, 0.0},
							  { 0.0, 0.0, 0.0} };
		double maskPrewitt_1[3][3] = { {-1.0, -1.0, -1.0},  // 프리윗 행 검출 마스크
						  { 0.0, 0.0, 0.0},
						  { 1.0, 1.0, 1.0} };

		double maskPrewitt_2[3][3] = { {1.0, 0.0, -1.0}, // 프리윗 열 검출 마스크
						  { 1.0, 0.0, -1.0},
						  {1.0, 0.0, -1.0} };
		double maskSobel_1[3][3] = { {-1.0, -2.0, -1.0}, // 소벨 행 검출 마스크 
							  { 0.0, 0.0, 0.0},
							  {1.0, 2.0, 1.0} };

		double maskSobel_2[3][3] = { {1.0, 0.0, -1.0}, // 소벨 열 검출 마스크 
							  { 2.0, 0.0, -2.0},
							  {1.0, 0.0, -1.0} };

		int checkmask = dlg.m_checkval1;
		int checkmask2 = dlg.m_checkval2;
		int checkmask3 = dlg.m_checkval3;

		double mask[3][3] = { 0.0, }, mask2[3][3] = { 0.0, };


		if (checkmask == 1 && checkmask2 == 1) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskRobert_1[i][k];
					mask2[i][k] = maskRobert_2[i][k];
				}
		}
		if (checkmask == 1 && checkmask2 == 2) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskRobert_2[i][k];
					mask2[i][k] = maskRobert_1[i][k];
				}
		}
		if (checkmask == 2 && checkmask2 == 1) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskPrewitt_1[i][k];
					mask2[i][k] = maskPrewitt_2[i][k];
				}
		}
		if (checkmask == 2 && checkmask2 == 2) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskPrewitt_2[i][k];
					mask2[i][k] = maskPrewitt_1[i][k];
				}
		}
		if (checkmask == 3 && checkmask2 == 1) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskSobel_1[i][k];
					mask2[i][k] = maskSobel_2[i][k];
				}

		}
		if (checkmask == 3 && checkmask2 == 2) {
			for (int i = 0; i < 3; i++) {
				for (int k = 0; k < 3; k++) {
					mask[i][k] = maskSobel_2[i][k];
					mask2[i][k] = maskSobel_1[i][k];
				}

			}
		}

		// 임시 메모리 할당(실수형)
		// 
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (3 - 1); i++)
			for (int k = 0; k < m_inW + (3 - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < 3; m++)
					for (int n = 0; n < 3; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
						if (checkmask3 == 1) {
							SR += tmpInImageR[i + m][k + n] * mask2[m][n];
							SG += tmpInImageG[i + m][k + n] * mask2[m][n];
							SB += tmpInImageB[i + m][k + n] * mask2[m][n];
						}
					}
				tmpoutImageR[i][k] = SR;
				tmpoutImageG[i][k] = SG;
				tmpoutImageB[i][k] = SB;
			}
		}
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				tmpoutImageR[i][k] += 127.0;
				tmpoutImageG[i][k] += 127.0;
				tmpoutImageB[i][k] += 127.0;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
	// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심

		OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnEdgelaplaceImage()
{
	// TODO: 여기에 구현 코드 추가.
	CLaplaceDlg dlg;

	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.

		double mask1[3][3] = { {0.0, -1.0, 0.0},  // 라플라시안 마스크 1
							  { -1.0, 4.0, -1.0},
							  { 0.0, -1.0, 0.0} };

		double mask2[3][3] = { {1.0, 1.0, 1.0},  // 라플라시안 마스크 2
							  { 1.0, -8.0, 1.0},
							  { 1.0, 1.0, 1.0} };
		double mask3[3][3] = { {-1.0, -1.0, -1.0},  // 라플라시안 마스크 3 
							  { -1.0, 8.0, -1.0},
							  { -1.0, -1.0, -1.0} };
		double mask[3][3];

		if (dlg.m_laplace != 1 && dlg.m_laplace != 2 && dlg.m_laplace != 3) {
			return;
		}
		if (dlg.m_laplace == 1) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++)
					mask[i][k] = mask1[i][k];
		}
		if (dlg.m_laplace == 2) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++)
					mask[i][k] = mask2[i][k];
		}
		if (dlg.m_laplace == 3) {
			for (int i = 0; i < 3; i++)
				for (int k = 0; k < 3; k++)
					mask[i][k] = mask3[i][k];
		}
		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (3 - 1); i++)
			for (int k = 0; k < m_inW + (3 - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < 3; m++)
					for (int n = 0; n < 3; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
					}
				tmpoutImageR[i][k] = SR;
				tmpoutImageG[i][k] = SG;
				tmpoutImageB[i][k] = SB;
			}
		}
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				tmpoutImageR[i][k] += 127.0;
				tmpoutImageG[i][k] += 127.0;
				tmpoutImageB[i][k] += 127.0;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)
	// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심

		OnFreeDouble2D(tmpInImageR, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (3 - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (3 - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnEdgelogImage()
{
	double mask[5][5] = { {0.0, 0.0,-1.0, 0.0,0.0},  // LoG 회선 마스크
								{0.0, -1.0,-2.0, -1.0,0.0},
								{-1.0, -2.0,16.0, -2.0,-1.0} ,
								{0.0, -1.0,-2.0,-1.0,0.0},
								{0.0,0.0,-1.0, 0.0,	0.0} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (5 - 1), m_inW + (5 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (5 - 1), m_inW + (5 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (5 - 1), m_inW + (5 - 1));
	double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (5 - 1); i++)
		for (int k = 0; k < m_inW + (5 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(5 / 2)][k + (int)(5 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(5 / 2)][k + (int)(5 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(5 / 2)][k + (int)(5 / 2)] = m_inImageB[i][k];
		}
	double SR, SG, SB;
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
			for (int m = 0; m < 5; m++)
				for (int n = 0; n < 5; n++) {
					SR += tmpInImageR[i + m][k + n] * mask[m][n];
					SG += tmpInImageG[i + m][k + n] * mask[m][n];
					SB += tmpInImageB[i + m][k + n] * mask[m][n];
				}
			tmpoutImageR[i][k] = SR;
			tmpoutImageG[i][k] = SG;
			tmpoutImageB[i][k] = SB;
		}
	}
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}

	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpoutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpoutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
			if (tmpoutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpoutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
			if (tmpoutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpoutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + (5 - 1));
	OnFreeDouble2D(tmpInImageG, m_inH + (5 - 1));
	OnFreeDouble2D(tmpInImageB, m_inH + (5 - 1));
	OnFreeDouble2D(tmpoutImageR, m_outH);
	OnFreeDouble2D(tmpoutImageG, m_outH);
	OnFreeDouble2D(tmpoutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnEdgedogImage()
{
	CEdgedogDlg dlg;

	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		////////////////
		// 화소 영역 처리
		/////////////////
		double mask1[7][7] = { {0.0, 0.0,-1.0,-1.0,-1.0, 0.0,0.0},  // DoG 검출 마스크 7x7 
								{0.0, -2.0,-3.0,-3.0,-3.0, -2.0,0.0},
								{-1.0, -3.0,5.0,5.0,5.0, -3.0,-1.0},
								{-1.0, -3.0,5.0,16.0,5.0, -3.0,-1.0},
								{-1.0, -3.0,5.0,5.0,5.0, -3.0,-1.0},
								{0.0, -2.0,-3.0,-3.0,-3.0, -2.0,0.0},
								{0.0, 0.0,-1.0,-1.0,-1.0, 0.0,0.0} };
		double mask2[9][9] = { {0.0, 0.0,0.0,-1.0,-1.0,-1.0, 0.0, 0.0,0.0},  // DoG 검출 마스크 9x9  
								{0.0, -2.0,-3.0,-3.0,-3.0,-3.0, -3.0, -2.0,0.0},
								{0.0, -3.0,-2.0,-1.0,-1.0,-1.0, -2.0, -3.0,0.0},
								{-1.0, -3.0,-1.0,9.0,9.0,9.0, -1.0, -3.0,-1.0},
								{-1.0, -3.0,-1.0,9.0,19.0,9.0, -1.0, -3.0,-1.0},
								{-1.0, -3.0,-1.0,9.0,9.0,9.0, -1.0, -3.0,-1.0},
								{0.0, -3.0,-2.0,-1.0,-1.0,-1.0, -2.0, -3.0,0.0},
								{0.0, -2.0,-3.0,-3.0,-3.0,-3.0, -3.0, -2.0,0.0},
								{0.0, 0.0,0.0,-1.0,-1.0,-1.0, 0.0, 0.0,0.0} };


		int checkmask = dlg.m_edgedog;
		if (checkmask % 2 == 0)
			checkmask++;
		int maskH = 7, maskW = 7;
		double** mask = OnMallocDouble2D(maskH, maskW);
		for (int i = 0; i < maskH; i++)
			for (int k = 0; k < maskW; k++)
				mask[i][k] = 0.0;
		if (checkmask != 7 && checkmask != 9) {
			return;
		}
		if (checkmask == 7) {
			maskH = maskW = 7;
			OnFreeDouble2D(mask, 7);
			mask = OnMallocDouble2D(maskH, maskW);
			for (int i = 0; i < maskH; i++)
				for (int k = 0; k < maskW; k++)
					mask[i][k] = mask1[i][k];
		}
		if (checkmask == 9) {
			maskH = maskW = 9;
			OnFreeDouble2D(mask, 7);
			mask = OnMallocDouble2D(maskH, maskW);
			for (int i = 0; i < maskH; i++)
				for (int k = 0; k < maskW; k++)
					mask[i][k] = mask2[i][k];
		}
		// 여러 번 실행할 때, 출력 이미지 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);

		double** tmpInImageR = OnMallocDouble2D(m_inH + (maskH - 1), m_inW + (maskH - 1));
		double** tmpInImageG = OnMallocDouble2D(m_inH + (maskH - 1), m_inW + (maskH - 1));
		double** tmpInImageB = OnMallocDouble2D(m_inH + (maskH - 1), m_inW + (maskH - 1));
		double** tmpoutImageR = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageG = OnMallocDouble2D(m_outH, m_outW);
		double** tmpoutImageB = OnMallocDouble2D(m_outH, m_outW);

		for (int i = 0; i < m_inH + (maskH - 1); i++)
			for (int k = 0; k < m_inW + (maskH - 1); k++) {
				tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
			}

		for (int i = 0; i < m_inH; i++)
			for (int k = 0; k < m_inW; k++) {
				tmpInImageR[i + (int)(maskH / 2)][k + (int)(maskH / 2)] = m_inImageR[i][k];
				tmpInImageG[i + (int)(maskH / 2)][k + (int)(maskH / 2)] = m_inImageG[i][k];
				tmpInImageB[i + (int)(maskH / 2)][k + (int)(maskH / 2)] = m_inImageB[i][k];
			}
		double SR, SG, SB;
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {
				SR = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SG = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				SB = 0.0; // 마스크와 입력값을 각각 곱해서 합한 값.
				for (int m = 0; m < maskH; m++)
					for (int n = 0; n < maskH; n++) {
						SR += tmpInImageR[i + m][k + n] * mask[m][n];
						SG += tmpInImageG[i + m][k + n] * mask[m][n];
						SB += tmpInImageB[i + m][k + n] * mask[m][n];
					}
				tmpoutImageR[i][k] = SR;
				tmpoutImageG[i][k] = SG;
				tmpoutImageB[i][k] = SB;
			}
		}

		// 후처리 (마스크 값의 합계에 따라서...)	
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			tmpoutImageR[i][k] += 127.0;
			tmpoutImageG[i][k] += 127.0;
			tmpoutImageB[i][k] += 127.0;
		}
	}
// 임시 출력 영상--> 출력 영상. 
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				if (tmpoutImageR[i][k] < 0.0)
					m_outImageR[i][k] = 0;
				else if (tmpoutImageR[i][k] > 255.0)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = (unsigned char)tmpoutImageR[i][k];
				if (tmpoutImageG[i][k] < 0.0)
					m_outImageG[i][k] = 0;
				else if (tmpoutImageG[i][k] > 255.0)
					m_outImageG[i][k] = 255;
				else
					m_outImageG[i][k] = (unsigned char)tmpoutImageG[i][k];
				if (tmpoutImageB[i][k] < 0.0)
					m_outImageB[i][k] = 0;
				else if (tmpoutImageB[i][k] > 255.0)
					m_outImageB[i][k] = 255;
				else
					m_outImageB[i][k] = (unsigned char)tmpoutImageB[i][k];
			}
		}

		// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

		// 영상처리 알고리즘 핵심
		OnFreeDouble2D(mask, maskH);

		OnFreeDouble2D(tmpInImageR, m_inH + (maskH - 1));
		OnFreeDouble2D(tmpInImageG, m_inH + (maskH - 1));
		OnFreeDouble2D(tmpInImageB, m_inH + (maskH - 1));
		OnFreeDouble2D(tmpoutImageR, m_outH);
		OnFreeDouble2D(tmpoutImageG, m_outH);
		OnFreeDouble2D(tmpoutImageB, m_outH);
	}
}


void CColorImageAlpha1Doc::OnMopingImage()
{
	OnFreeEffectImage();
	BOOL result = OnEffectImageload();
	if (result == TRUE) {

		CMopingDlg dlg2;

		if (dlg2.DoModal() == IDOK) {
			OnForwardReductEffectImage();
			// 모핑할 이미지 로드
			// 중요! 출력 이미지의 크기를 결정 --> 알고리즘에 의존!

			// 메모리 해제
			OnFreeOutImage();
			int cx, cy, cx2, cy2;
			int s_H, s_W;
			cx =  m_inH / 2;
			cy = m_inW / 2;

			cx2 = m_effectH / 2;
			cy2 = m_effectW / 2;
			// 메모리 할당
			m_outH  = m_inH;
			m_outW = m_inW;
			m_outImageR = OnMalloc2D(m_outH, m_outW);
			m_outImageG = OnMalloc2D(m_outH, m_outW);
			m_outImageB = OnMalloc2D(m_outH, m_outW);

			double m_effectImageper = (double)dlg2.m_moping;
			// 입력 배열 --> 출력 배열
			int xs = 0, ys = 0;
			double valueR = 0, valueG = 0, valueB = 0;
			int outvR, outvG, outvB;
			outvR = outvG = outvB = 0;
			for (int i = 0; i < m_outH; i++) {
				for (int k = 0; k < m_outW; k++) {
					int xd = i;
					int yd = k;

					xs = (int)((double)cx - cx2);
					ys = (int)((double)cy - cy2);


					if ((xs <= xd && xd < xs + m_effectH) && (ys <= yd && yd < ys + m_effectW)) {
						valueR = fabs((double)(m_inImageR[xd][yd] - m_effectImageR[xd - xs][yd - ys]));
						valueG = fabs((double)(m_inImageG[xd][yd] - m_effectImageG[xd - xs][yd - ys]));
						valueB = fabs((double)(m_inImageB[xd][yd] - m_effectImageB[xd - xs][yd - ys]));
						if (m_inImageR[xd][yd] <= m_effectImageR[xd - xs][yd - ys])
							outvR = (int)((double)m_effectImageR[xd - xs][yd - ys] - valueR * (1.0 - (m_effectImageper / 100.0)));
						else
							outvR = (int)((double)m_effectImageR[xd - xs][yd - ys] + valueR * (1.0 - (m_effectImageper / 100.0)));
						if (m_inImageG[xd][yd] <= m_effectImageG[xd - xs][yd - ys])
							outvG = (int)((double)m_effectImageG[xd - xs][yd - ys] - valueG * (1.0 - (m_effectImageper / 100.0)));
						else
							outvG = (int)((double)m_effectImageG[xd - xs][yd - ys] + valueG * (1.0 - (m_effectImageper / 100.0)));
						if (m_inImageB[xd][yd] <= m_effectImageB[xd - xs][yd - ys])
							outvB = (int)((double)m_effectImageB[xd - xs][yd - ys] - valueB * (1.0 - (m_effectImageper / 100.0)));
						else
							outvB = (int)((double)m_effectImageB[xd - xs][yd - ys] + valueB * (1.0 - (m_effectImageper / 100.0)));
					}
					else {
						outvR = m_inImageR[xd][yd];
						outvG = m_inImageG[xd][yd];
						outvB = m_inImageB[xd][yd];
					}
					if (outvR > 255)
						outvR = 255;
					if (outvR < 0)
						outvR = 0;
					m_outImageR[xd][yd] = outvR;
					if (outvG > 255)
						outvG = 255;
					if (outvG < 0)
						outvG = 0;
					m_outImageG[xd][yd] = outvG;
					if (outvB > 255)
						outvB = 255;
					if (outvB < 0)
						outvB = 0;
					m_outImageB[xd][yd] = outvB;
				}
			}
		}
	}
}

BOOL CColorImageAlpha1Doc::OnEffectImageload()
{
	// _T("Excel 파일 (*.xls, *.xlsx) |*.xls; *.xlsx|"); 와 같이 확장자를 제한하여 표시할 수 있음
	CString str = _T("All files(*.*)|*.*|");

	CFileDialog dlg(TRUE, _T(".dat"), NULL, OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST, str);

	if (dlg.DoModal() == IDOK)
	{
		CString strPathName = dlg.GetPathName();
		// CString을 LPCTSTR로 변환합니다.

		LPCTSTR lpszPathName = static_cast<LPCTSTR>(strPathName);
		if (m_effectImageR != NULL) {
			OnFree2d(m_effectImageR, m_effectH);
			OnFree2d(m_effectImageG, m_effectH);
			OnFree2d(m_effectImageB, m_effectH);
			m_effectImageR = m_effectImageG = m_effectImageB = NULL;
			m_effectH = m_effectW = 0;
		}

		// TODO:  여기에 특수화된 작성 코드를 추가합니다.
		CImage image;
		image.Load(lpszPathName);
		// (중요!) 입력 영상 크기 알아내기~
		m_effectH = image.GetHeight();
		m_effectW = image.GetWidth();
		// 메모리 할당
		m_effectImageR = OnMalloc2D(m_effectH, m_effectW);
		m_effectImageG = OnMalloc2D(m_effectH, m_effectW);
		m_effectImageB = OnMalloc2D(m_effectH, m_effectW);
		// CImage의 객체값 --> 메모리
		COLORREF  px;
		for (int i = 0; i < m_effectH; i++)
			for (int k = 0; k < m_effectW; k++) {
				px = image.GetPixel(k, i);
				m_effectImageR[i][k] = GetRValue(px);
				m_effectImageG[i][k] = GetGValue(px);
				m_effectImageB[i][k] = GetBValue(px);
			}

		return TRUE;
	}
	return FALSE;
}


void CColorImageAlpha1Doc::OnFreeEffectImage()
{
	// TODO: 여기에 구현 코드 추가.
	if (m_effectImageR != NULL) {
		OnFree2d(m_effectImageR, m_effectH);
		OnFree2d(m_effectImageG, m_effectH);
		OnFree2d(m_effectImageB, m_effectH);
		m_effectImageR = m_effectImageG = m_effectImageB = NULL;
		m_effectH = m_effectW = 0;
	}
}


void CColorImageAlpha1Doc::OnForwardReductEffectImage()
{
	// TODO: 여기에 구현 코드 추가.
	int changeeffectH = m_effectH; int changeeffectW = m_effectW;
		if (changeeffectH % 2 != 0)
			changeeffectH--;
		if (changeeffectW % 2 != 0)
			changeeffectW--;

		int tempH = changeeffectH;

		int tempW = changeeffectW;

		unsigned char** tempImageR = OnMalloc2D(tempH, tempW);
		unsigned char** tempImageG = OnMalloc2D(tempH, tempW);
		unsigned char** tempImageB = OnMalloc2D(tempH, tempW);

		// 메모리 할당
		for (int i = 0; i < tempH; i++) {
			for (int k = 0; k < tempW; k++) {
				tempImageR[i][k] = m_effectImageR[i][k];
				tempImageG[i][k] = m_effectImageG[i][k];
				tempImageB[i][k] = m_effectImageB[i][k];
			}
		}

		OnFreeEffectImage();
		int scaleh = 2;
		int scalew = 2;

		int efh, efw;
		efh = (int)(tempH / 2);
		efw = (int)(tempW / 2);
		for (int i = 1; m_inH/2 <= efh || m_inW/2 <= efw; i++) {
			if (efh % 2 != 0)
				efh--;
			efh = (int)(efh / (2 * i));
			if (efw % 2 != 0)
				efw--;
			efw = (int)(efw / (2 * i));
			scaleh = scalew = 2*(1+i) ;
		}
		if (efh % 2 != 0)
			efh--;
		if (efw % 2 != 0)
			efw--;

		m_effectH = efh;

		m_effectW = efw;

		m_effectImageR = OnMalloc2D(m_effectH, m_effectW);
		m_effectImageG = OnMalloc2D(m_effectH, m_effectW);
		m_effectImageB = OnMalloc2D(m_effectH, m_effectW);

		double sumR, sumG, sumB;
		double medR, medG, medB;
		for (int i = 0; i < m_effectH * scaleh; i+= scaleh) {
			for (int k = 0; k < m_effectW * scalew; k+= scalew) {
				sumR = sumG = sumB = 0.0;
				medR = medG = medB = 0.0;
				for (int a = i; a < (int)(i + scaleh); a++) {
					for (int b = k; b < (int)(k + scalew); b++) {
						if ((0 <= a && a < tempH) && (0 <= b && b < tempW)) {
							sumR += tempImageR[a][b];
							sumG += tempImageG[a][b];
							sumB += tempImageB[a][b];
						}
					}
				}
				medR = sumR / (scaleh * scalew);
				medG = sumG / (scaleh * scalew);
				medB = sumB / (scaleh * scalew);

				m_effectImageR[(int)(i / scaleh)][(int)(k / scalew)] = (unsigned char)medR;
				m_effectImageG[(int)(i / scaleh)][(int)(k / scalew)] = (unsigned char)medG;
				m_effectImageB[(int)(i / scaleh)][(int)(k / scalew)] = (unsigned char)medB;

			}

		}
		OnFree2d(tempImageR,tempH);

		OnFree2d(tempImageG, tempH);

		OnFree2d(tempImageB, tempH);

}


void CColorImageAlpha1Doc::OnSpecificationImage()
{
	OnEffectImageload();
	// 메모리 해제			
	OnFreeOutImage();
	m_outH  = m_inH;
	m_outW = m_inW;
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// 1단계 빈도수 세기(=히스토그램)
	int histoR[256] = { 0, };
	int histoG[256] = { 0, };
	int histoB[256] = { 0, };

	int histo2R[256] = { 0, };
	int histo2G[256] = { 0, };
	int histo2B[256] = { 0, };
	int top = 255, bottom = top - 1;
	//DMIN = m_Sum_Of_DHIST[0];
	//DMAX = m_Sum_Of_DHIST[255];
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			histoR[m_inImageR[i][k]]++;
			histoG[m_inImageG[i][k]]++;
			histoB[m_inImageB[i][k]]++;
		}
	}
	for (int i = 0; i < m_effectH; i++) {
		for (int k = 0; k < m_effectW; k++) {
			histo2R[m_effectImageR[i][k]]++;
			histo2G[m_effectImageG[i][k]]++;
			histo2B[m_effectImageB[i][k]]++;
		}
	}
	// 2단계 누적히스토그램 생성
	int sumHistoR[256] = { 0, };
	int sumHistoG[256] = { 0, };
	int sumHistoB[256] = { 0, };
	int sumHisto2R[256] = { 0, };
	int sumHisto2G[256] = { 0, };
	int sumHisto2B[256] = { 0, };

	sumHistoR[0] = histoR[0];
	sumHistoG[0] = histoG[0];
	sumHistoB[0] = histoB[0];
	for (int i = 1; i < 256; i++) {
		sumHistoR[i] = sumHistoR[i - 1] + histoR[i];
		sumHistoG[i] = sumHistoG[i - 1] + histoG[i];
		sumHistoB[i] = sumHistoB[i - 1] + histoB[i];

	}

	for (int i = 1; i < 256; i++) {
		sumHisto2R[i] = sumHisto2R[i - 1] + histo2R[i];
		sumHisto2G[i] = sumHisto2G[i - 1] + histo2G[i];
		sumHisto2B[i] = sumHisto2B[i - 1] + histo2B[i];
	}

	// 3단계 정규화된 히스토그램 생성 nomalHisto = sumHist * (1.0/(inH*inW)) * 255.0)
	double** normalHistoR = OnMallocDouble2D(m_inH, m_inW);
	double** normalHistoG = OnMallocDouble2D(m_inH, m_inW);
	double** normalHistoB = OnMallocDouble2D(m_inH, m_inW);

	double normalHisto2R[256] = { 0, };
	double normalHisto2G[256] = { 0, };
	double normalHisto2B[256] = { 0, };

	double* reverse_histoR = new double[m_outH * m_outW];
	double* reverse_histoG = new double[m_outH * m_outW];
	double* reverse_histoB = new double[m_outH * m_outW];

	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			normalHistoR[i][k] = sumHistoR[m_inImageR[i][k]] * (1.0 / (m_inH * m_inW)) * 255.0;
			normalHistoG[i][k] = sumHistoG[m_inImageG[i][k]] * (1.0 / (m_inH * m_inW)) * 255.0;
			normalHistoB[i][k] = sumHistoB[m_inImageB[i][k]] * (1.0 / (m_inH * m_inW)) * 255.0;
		}
	}
	int DMINR = sumHisto2R[0];
	int DMING = sumHisto2G[0];
	int DMINB = sumHisto2B[0];
	int DMAXR = sumHisto2R[255];
	int DMAXG = sumHisto2G[255];
	int DMAXB = sumHisto2B[255];

	// 원하는 영상을 평활화
	for (int i = 0; i < 256; i++) {
		normalHisto2R[i] = (sumHisto2R[i] - DMINR) * m_inH / (DMAXR - DMINR);
		normalHisto2G[i] = (sumHisto2G[i] - DMING) * m_inH / (DMAXG - DMING);
		normalHisto2B[i] = (sumHisto2B[i] - DMINB) * m_inH / (DMAXB - DMINB);

	}
	// 룩업테이블을 이용한 명세화
	while (1) {
		for (int i = (int)normalHisto2R[bottom]; i <= (int)normalHisto2R[top]; i++) {
			reverse_histoR[i] = top;
		}
		top = bottom;
		bottom = bottom - 1;
		if (bottom <= -1)
			break;
	}

	top = 255; bottom = top - 1;
	while (1) {
		for (int i = (int)normalHisto2G[bottom]; i <= (int)normalHisto2G[top]; i++) {
			reverse_histoG[i] = top;
		}
		top = bottom;
		bottom = bottom - 1;
		if (bottom <= -1)
			break;
	}

	top = 255; bottom = top - 1;
	while (1) {
		for (int i = (int)normalHisto2B[bottom]; i <= (int)normalHisto2B[top]; i++) {
			reverse_histoB[i] = top;
		}
		top = bottom;
		bottom = bottom - 1;
		if (bottom <= -1)
			break;
	}
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			m_outImageR[i][k] = (unsigned char)reverse_histoR[(int)normalHistoR[i][k]];
			m_outImageG[i][k] = (unsigned char)reverse_histoG[(int)normalHistoG[i][k]];
			m_outImageB[i][k] = (unsigned char)reverse_histoB[(int)normalHistoB[i][k]];
		}
	}
	OnFreeDouble2D(normalHistoR, m_inH);
	OnFreeDouble2D(normalHistoG, m_inH);
	OnFreeDouble2D(normalHistoB, m_inH);
	delete[] reverse_histoR;
	delete[] reverse_histoG;
	delete[] reverse_histoB;
}


void CColorImageAlpha1Doc::OnColoroutImage()
{
	// TODO: 여기에 구현 코드 추가.
	// 기존 메모리 해제

	CRealcoloroutDlg dlg;

	if (dlg.DoModal() == IDOK) {
		int inKey = dlg.m_colorval;
		int startval = 0; 
		int endval = 360;
		switch (inKey) {
		case 1://빨간색
			startval = 0;
			endval = 8;
			break;
		case 2://주황색
			startval = 8;
			endval = 20;
			break;
		case 3://노란색
			startval = 55;
			endval = 65;
			break;
		case 4://초록색
			startval = 100;
			endval = 145;
			break;
		case 5://파랑색
			startval = 200;
			endval = 225;
			break;
		case 6://남색
			startval = 235;
			endval = 250;
			break;
		case 7://보라색
			startval = 285;
			endval = 320;
			break;
		}

		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		double H, S, I;
		unsigned char R, G, B;
		// ** 진짜 영상처리 알고리즘 **
		for (int i = 0; i < m_inH; i++) {
			for (int k = 0; k < m_inW; k++) {

				// HIS 모델 값
				// H(색상) : 0 ~ 360
				// S(채도) : 0.0 ~ 1.0
				// I(명도) : 0 ~ 255

				// RGB --> HSI
				R = m_inImageR[i][k];
				G = m_inImageG[i][k];
				B = m_inImageB[i][k];

				double* hsi = RGB2HSI(R, G, B);
				H = hsi[0];
				S = hsi[1];
				I = hsi[2];

				// 오렌지 추출 ( H : 8~20)
				if (startval <= H && H <= endval) {

					m_outImageR[i][k] = m_inImageR[i][k];
					m_outImageG[i][k] = m_inImageG[i][k];
					m_outImageB[i][k] = m_inImageB[i][k];

				}
				else {
					double avg = (m_inImageR[i][k] + m_inImageG[i][k] + m_inImageB[i][k]) / 3.0;
					m_outImageR[i][k] = m_outImageG[i][k] = m_outImageB[i][k] = (unsigned char)avg;
				}

			}
		}
	}
}


void CColorImageAlpha1Doc::OnEmbosshsiImage(){
}


void CColorImageAlpha1Doc::OnWatermarkspaceImage()
{
	OnEffectImageload();
	// 메모리 해제
	int changeeffectH, changeeffectW;
	changeeffectH = m_effectH;
	changeeffectW = m_effectW;
	if (changeeffectH % 2 != 0)
		changeeffectH--;
	if (changeeffectW % 2 != 0)
		changeeffectW--;
	if (m_effectH >= m_inH/2|| m_effectW >= m_inW/2) {
		OnForwardReductEffectImage();
	}

	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// 1단계 빈도수 세기(=히스토그램)
	//DMAX = m_Sum_Of_DHIST[255];
	unsigned char** inputwaterImageR = OnMalloc2D(m_effectH, m_effectW);
	unsigned char** inputwaterImageG = OnMalloc2D(m_effectH, m_effectW);
	unsigned char** inputwaterImageB = OnMalloc2D(m_effectH, m_effectW);

	int inputwaterH = m_effectH;
	int inputwaterW = m_effectW;
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			m_outImageR[i][k] = m_inImageR[i][k];
			m_outImageG[i][k] = m_inImageG[i][k];
			m_outImageB[i][k] = m_inImageB[i][k];
		}
	}
	for (int a = 0; a < 2; a++) {
		for (int b = 0; b < 2; b++) {
			for (int c = 0; c < m_effectH; c++) {
				for (int d = 0; d < m_effectW; d++) {
					inputwaterImageR[c][d] = m_effectImageR[c][d] & (unsigned char)((unsigned char)0b10000000 >> (a * 2 + b));
					inputwaterImageR[c][d] = inputwaterImageR[c][d] >> (7 - (a * 2 + b));
					inputwaterImageG[c][d] = m_effectImageG[c][d] & (unsigned char)((unsigned char)0b10000000 >> (a * 2 + b));
					inputwaterImageG[c][d] = inputwaterImageG[c][d] >> (7 - (a * 2 + b));
					inputwaterImageB[c][d] = m_effectImageB[c][d] & (unsigned char)((unsigned char)0b10000000 >> (a * 2 + b));
					inputwaterImageB[c][d] = inputwaterImageB[c][d] >> (7 - (a * 2 + b));
				}
			}
			for (int i = (int)(m_inH*a / 2) ; i < (int)((int)(m_inH*a / 2) + (int)(inputwaterH)-1); i++) {
				for (int k = (int)(m_inW*b / 2) ; k < (int)((int)(m_inW*b  / 2) + (int)(inputwaterW)-1); k++) {
	
					int valH = (int)(m_inH * a / 2);
					int valW = (int)(m_inW * b / 2);
					int inputH = i - valH;
					int inputW = k - valW;
					m_outImageR[i][k] = (unsigned char)(m_inImageR[i][k] & ~(unsigned char)1) | inputwaterImageR[inputH][inputW];
					m_outImageG[i][k] = (unsigned char)(m_inImageG[i][k] & ~(unsigned char)1) | inputwaterImageG[inputH][inputW];
					m_outImageB[i][k] = (unsigned char)(m_inImageB[i][k] & ~(unsigned char)1) | inputwaterImageB[inputH][inputW];
				}
			}
		}
	}
	OnFree2d(inputwaterImageR, inputwaterH);
	OnFree2d(inputwaterImageG, inputwaterH);
	OnFree2d(inputwaterImageB, inputwaterH);
	//CString str1;    
	//str1.Format(_T("%d"), scaleH);
	//CString str2;
	//str2.Format(_T("%d"), scaleW);
	//MessageBox(NULL, L"입력된 워터마크의 축소 비율 : H = " + str1 + " W = " + str2, L"워터마크 축소 비율 확인", NULL);

	CString str3;
	str3.Format(_T("%d"), inputwaterH);
	CString str4;
	str4.Format(_T("%d"), inputwaterW);
	MessageBox(NULL, L"입력된 워터마크의 크기 : H = " + str3 + " W = " + str4,L"워터마크 축소 비율 확인", NULL);

}


void CColorImageAlpha1Doc::OnWatermarkspaceoutImage()
{
	CWaterimageoutDlg dlg;

	if (dlg.DoModal() == IDOK) {
		int waterinputh = dlg.m_waterH;
		int waterinputw = dlg.m_waterW;

		int scale = dlg.m_reductscale;
		int scaleH = scale,scaleW = scale;

		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = waterinputh;
		m_outW = waterinputw;

		if (m_outH > m_inH || m_outW > m_inW || m_outH > m_inW || m_outW > m_inH)
			return;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// 메모리 할당
		// 1단계 빈도수 세기(=히스토그램)
		//DMAX = m_Sum_Of_DHIST[255];
		for (int i = 0; i < m_outH; i++) {
			for (int k = 0; k < m_outW; k++) {
				m_outImageR[i][k] = 0;
				m_outImageG[i][k] = 0;
				m_outImageB[i][k] = 0;
			}
		}
		for (int a = 0; a < 2; a++) {
			for (int b = 0; b < 2; b++) {
				for (int i = (int)(m_inH * a / 2); i < (int)((int)(m_inH * a / 2) + (int)(waterinputh)); i++) {
					for (int k = (int)(m_inW * b / 2); k < (int)((int)(m_inW*b / 2) + (int)(waterinputw)); k++) {
						int valH = (int)(m_inH * a / 2);
						int valW = (int)(m_inW * b / 2);
						int inputH = i - valH;
						int inputW = k - valW;
						unsigned char valR = (unsigned char)((m_inImageR[i][k] & (unsigned char)1) << (7 - (a * 2 + b)));
						unsigned char valG = (unsigned char)((m_inImageG[i][k] & (unsigned char)1) << (7 - (a * 2 + b)));
						unsigned char valB = (unsigned char)((m_inImageB[i][k] & (unsigned char)1) << (7 - (a * 2 + b)));
						m_outImageR[inputH][inputW] += valR;
						m_outImageG[inputH][inputW] += valG;
						m_outImageB[inputH][inputW] += valB;
					}
				}
			}
		}
	}
}


void CColorImageAlpha1Doc::OnEmbossHsi()
{

	// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;
	double mask[MSIZE][MSIZE] = {  // 엠보싱 마스크
		{ -1.0, 0.0, 0.0 },
		{  0.0, 0.0, 0.0 },
		{  0.0, 0.0, 1.0 } };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageG = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageB = OnMallocDouble2D(m_inH + 2, m_inW + 2);

	tmpInImageH = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageS = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageI = OnMallocDouble2D(m_inH + 2, m_inW + 2);

	tmpOutImageR = OnMallocDouble2D(m_outH, m_outW);
	tmpOutImageG = OnMallocDouble2D(m_outH, m_outW);
	tmpOutImageB = OnMallocDouble2D(m_outH, m_outW);

	// 임시 메모리 초기화 (127)
	for (int i = 0; i < m_inH + 2; i++)
		for (int k = 0; k < m_inW + 2; k++)
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127.0;

	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFreeDouble2D(tmpInImageR, m_inH + 2);
	OnFreeDouble2D(tmpInImageG, m_inH + 2);
	OnFreeDouble2D(tmpInImageB, m_inH + 2);
	OnFreeDouble2D(tmpInImageH, m_inH + 2);
	OnFreeDouble2D(tmpInImageS, m_inH + 2);
	OnFreeDouble2D(tmpInImageI, m_inH + 2);
	OnFreeDouble2D(tmpOutImageR, m_outH);
	OnFreeDouble2D(tmpOutImageG, m_outH);
	OnFreeDouble2D(tmpOutImageB, m_outH);
}


void CColorImageAlpha1Doc::OnEdgeverticalhsiImage()
{
	const int MSIZE = 3;
	double mask[3][3] = { {0.0, 0.0, 0.0}, // 수직 에지 마스크
						 { -1.0, 1.0, 0.0},
						 { 0.0, 0.0, 0.0} };
	// 여러 번 실행할 때, 출력 이미지 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);

	double** tmpInImageR = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageG = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	double** tmpInImageB = OnMallocDouble2D(m_inH + (3 - 1), m_inW + (3 - 1));
	
	double ** tmpInImageH = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	double** tmpInImageS = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	double** tmpInImageI = OnMallocDouble2D(m_inH + 2, m_inW + 2);

	double** tmpOutImageR = OnMallocDouble2D(m_outH, m_outW);
	double** tmpOutImageG = OnMallocDouble2D(m_outH, m_outW);
	double** tmpOutImageB = OnMallocDouble2D(m_outH, m_outW);

	for (int i = 0; i < m_inH + (3 - 1); i++)
		for (int k = 0; k < m_inW + (3 - 1); k++) {
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127;
		}

	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageR[i][k];
			tmpInImageG[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageG[i][k];
			tmpInImageB[i + (int)(3 / 2)][k + (int)(3 / 2)] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}

	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}
	// 후처리 (마스크 값의 합계에 따라서...)
// 임시 출력 영상--> 출력 영상. 
	for (int i = 0; i < m_outH; i++) {
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];
			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageG[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];
			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];
		}
	}

	// (중요!) 출력 영상 크기 결정 -->알고리즘에 의존

	// 영상처리 알고리즘 핵심

	OnFreeDouble2D(tmpInImageR, m_inH + 2);
	OnFreeDouble2D(tmpInImageG, m_inH + 2);
	OnFreeDouble2D(tmpInImageB, m_inH + 2);
	OnFreeDouble2D(tmpInImageH, m_inH + 2);
	OnFreeDouble2D(tmpInImageS, m_inH + 2);
	OnFreeDouble2D(tmpInImageI, m_inH + 2);
	OnFreeDouble2D(tmpOutImageR, m_outH);
	OnFreeDouble2D(tmpOutImageG, m_outH);
	OnFreeDouble2D(tmpOutImageB, m_outH);
}



void CColorImageAlpha1Doc::OnEdgehorizontalhsiImage()
{
	// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
	OnFreeOutImage();
	// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
	m_outH = m_inH;
	m_outW = m_inW;
	// 메모리 할당
	m_outImageR = OnMalloc2D(m_outH, m_outW);
	m_outImageG = OnMalloc2D(m_outH, m_outW);
	m_outImageB = OnMalloc2D(m_outH, m_outW);
	// ** 진짜 영상처리 알고리즘 **
	const int MSIZE = 3;

	double mask[MSIZE][MSIZE] = { {0.0, -1.0, 0.0}, // 수평 에지 마스크
				  { 0.0, 1.0, 0.0},
				  { 0.0, 0.0, 0.0} };

	// 임시 메모리 할당
	double** tmpInImageR, ** tmpInImageG, ** tmpInImageB, ** tmpOutImageR, ** tmpOutImageG, ** tmpOutImageB;
	double** tmpInImageH, ** tmpInImageS, ** tmpInImageI;
	tmpInImageR = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageG = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageB = OnMallocDouble2D(m_inH + 2, m_inW + 2);

	tmpInImageH = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageS = OnMallocDouble2D(m_inH + 2, m_inW + 2);
	tmpInImageI = OnMallocDouble2D(m_inH + 2, m_inW + 2);

	tmpOutImageR = OnMallocDouble2D(m_outH, m_outW);
	tmpOutImageG = OnMallocDouble2D(m_outH, m_outW);
	tmpOutImageB = OnMallocDouble2D(m_outH, m_outW);

	// 임시 메모리 초기화 (127)
	for (int i = 0; i < m_inH + 2; i++)
		for (int k = 0; k < m_inW + 2; k++)
			tmpInImageR[i][k] = tmpInImageG[i][k] = tmpInImageB[i][k] = 127.0;

	// 입력메모리 --> 임시입력메모리
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageR[i + 1][k + 1] = m_inImageR[i][k];
			tmpInImageG[i + 1][k + 1] = m_inImageG[i][k];
			tmpInImageB[i + 1][k + 1] = m_inImageB[i][k];
		}

	///////// RGB 모델 --> HSI 모델 ///////////////
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double* hsi;
			unsigned char R, G, B;
			R = tmpInImageR[i][k]; G = tmpInImageG[i][k]; B = tmpInImageB[i][k];
			hsi = RGB2HSI(R, G, B);

			double H, S, I;
			H = hsi[0]; S = hsi[1]; I = hsi[2];
			tmpInImageH[i][k] = H; tmpInImageS[i][k] = S; tmpInImageI[i][k] = I;
		}
	}
	// *** 회선 연산 : 마스크로 긁어가면서 계산하기.	
	for (int i = 0; i < m_inH; i++) {
		for (int k = 0; k < m_inW; k++) {
			double S_VALUE = 0.0;
			for (int m = 0; m < MSIZE; m++)
				for (int n = 0; n < MSIZE; n++)
					S_VALUE += tmpInImageI[i + m][k + n] * mask[m][n];
			tmpInImageI[i][k] = S_VALUE;
		}
	}

	// 후처리 (마스크의 합계에 따라서 127을 더할지 결정)
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			tmpInImageI[i][k] += 127;
		}

	////// HSI --> RGB ////////
	for (int i = 0; i < m_inH; i++)
		for (int k = 0; k < m_inW; k++) {
			unsigned char* rgb;
			double H, S, I;

			H = tmpInImageH[i][k]; S = tmpInImageS[i][k]; I = tmpInImageI[i][k];

			rgb = HSI2RGB(H, S, I);
			tmpOutImageR[i][k] = rgb[0]; tmpOutImageG[i][k] = rgb[1]; tmpOutImageB[i][k] = rgb[2];
		}


	// 임시 출력 이미지 ---> 출력 이미지
	for (int i = 0; i < m_outH; i++)
		for (int k = 0; k < m_outW; k++) {
			if (tmpOutImageR[i][k] < 0.0)
				m_outImageR[i][k] = 0;
			else if (tmpOutImageR[i][k] > 255.0)
				m_outImageR[i][k] = 255;
			else
				m_outImageR[i][k] = (unsigned char)tmpOutImageR[i][k];

			if (tmpOutImageG[i][k] < 0.0)
				m_outImageG[i][k] = 0;
			else if (tmpOutImageG[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageG[i][k] = (unsigned char)tmpOutImageG[i][k];

			if (tmpOutImageB[i][k] < 0.0)
				m_outImageB[i][k] = 0;
			else if (tmpOutImageB[i][k] > 255.0)
				m_outImageB[i][k] = 255;
			else
				m_outImageB[i][k] = (unsigned char)tmpOutImageB[i][k];

		}


	// 임시 메모리 해제
	OnFreeDouble2D(tmpInImageR, m_inH + 2);
	OnFreeDouble2D(tmpInImageG, m_inH + 2);
	OnFreeDouble2D(tmpInImageB, m_inH + 2);
	OnFreeDouble2D(tmpInImageH, m_inH + 2);
	OnFreeDouble2D(tmpInImageS, m_inH + 2);
	OnFreeDouble2D(tmpInImageI, m_inH + 2);
	OnFreeDouble2D(tmpOutImageR, m_outH);
	OnFreeDouble2D(tmpOutImageG, m_outH);
	OnFreeDouble2D(tmpOutImageB, m_outH);
}



void CColorImageAlpha1Doc::OnImpressImage()
{
	CImpressimage dlg;
	if (dlg.DoModal() == IDOK) {
		// TODO: 여기에 구현 코드 추가.
		// 기존 메모리 해제
		OnFreeOutImage();
		// 중요! 출력 이미지 크기 결정 --> 알고리즘에 따름...
		m_outH = m_inH;
		m_outW = m_inW;
		// 메모리 할당
		m_outImageR = OnMalloc2D(m_outH, m_outW);
		m_outImageG = OnMalloc2D(m_outH, m_outW);
		m_outImageB = OnMalloc2D(m_outH, m_outW);
		// ** 진짜 영상처리 알고리즘 **
		// 이미지 포스터라이징(입력된 값을 라이징 값으로 입력받음)
		for (int i = 0; i < m_inH; i++)
		{
			for (int k = 0; k < m_inW; k++)
			{
				if (m_inImageR[i][k] >= dlg.m_RST && m_inImageR[i][k] <= dlg.m_RED)
					m_outImageR[i][k] = 255;
				else
					m_outImageR[i][k] = m_inImageR[i][k];
			}
		}
			for (int i = 0; i < m_inH; i++)
			{
				for (int k = 0; k < m_inW; k++)
				{
					if (m_inImageG[i][k] >= dlg.m_GST && m_inImageG[i][k] <= dlg.m_GED)
						m_outImageG[i][k] = 255;
					else
						m_outImageG[i][k] = m_inImageG[i][k];
				}
			}
			for (int i = 0; i < m_inH; i++)
			{
				for (int k = 0; k < m_inW; k++)
				{
					if (m_inImageB[i][k] >= dlg.m_BST && m_inImageB[i][k] <= dlg.m_BED)
						m_outImageB[i][k] = 255;
					else
						m_outImageB[i][k] = m_inImageB[i][k];
				}
			}
	}
}

﻿#pragma once
#include "afxdialogex.h"


// CMaskscaleDlg 대화 상자

class CMaskscaleDlg : public CDialog
{
	DECLARE_DYNAMIC(CMaskscaleDlg)

public:
	CMaskscaleDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CMaskscaleDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MASKSCALE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_maskscale;
};

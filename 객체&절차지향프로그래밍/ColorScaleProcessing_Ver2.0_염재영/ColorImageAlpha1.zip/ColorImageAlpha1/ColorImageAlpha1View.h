﻿
// ColorImageAlpha1View.h: CColorImageAlpha1View 클래스의 인터페이스
//

#pragma once


class CColorImageAlpha1View : public CView
{
protected: // serialization에서만 만들어집니다.
	CColorImageAlpha1View() noexcept;
	DECLARE_DYNCREATE(CColorImageAlpha1View)

// 특성입니다.
public:
	CColorImageAlpha1Doc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CColorImageAlpha1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEqualImage();
	afx_msg void OnGrayScale();
	afx_msg void OnAdderImage();
	afx_msg void OnInverseImage();
	afx_msg void OnBinization128Image();
	afx_msg void OnBinizationavgImage();
	afx_msg void OnBinizationmidImage();
	afx_msg void OnPosterImage();
	afx_msg void OnAndbitImage();
	afx_msg void OnOrbitImage();
	afx_msg void OnXorbitImage();
	afx_msg void OnMulImage();
	afx_msg void OnDivImage();
	afx_msg void OnParabolacapImage();
	afx_msg void OnParabolacupImage();
	afx_msg void OnGammaImage();
	afx_msg void OnBlurImage();
	afx_msg void OnSharpImage();
	afx_msg void OnEmbossImage();
	afx_msg void OnGaussImage();
	afx_msg void OnHighsharpImage();
	afx_msg void OnLowsharpImage();
	afx_msg void OnChangeSatur();
	afx_msg void OnPickorangeImage();
	afx_msg void OnForwardreductImage();
	afx_msg void OnForwardmedreductImage();
	afx_msg void OnForwardmidreductImage();
	afx_msg void OnForwardenlargeImage();
	afx_msg void OnBackwardenlargeImage();
	afx_msg void OnBackwardenlargeboganImage();
	afx_msg void OnForwardrotateImage();
	afx_msg void OnBackwardrotateImage();
	afx_msg void OnEnlargerotateImage();
	afx_msg void OnEnlargeboganrotateImage();
	afx_msg void OnMoveImage();
	afx_msg void OnSymmetryImage();
	afx_msg void OnEndinImage();
	afx_msg void OnDefaultstrechImage();
	afx_msg void OnHistosmoothImage();
	afx_msg void OnEdgeverticalImage();
	afx_msg void OnEdgehorizontalImage();
	afx_msg void OnEdgehomogenImage();
	afx_msg void OnEdgesubImage();
	afx_msg void OnEdgefirstderivativeImage();
	afx_msg void OnEdgelaplaceImage();
	afx_msg void OnEdgelogImage();
	afx_msg void OnEdgedogImage();
	afx_msg void OnMopingImage();
	afx_msg void OnSpecificationImage();
	afx_msg void OnColoroutImage();
	afx_msg void OnEmbosshsiImage();
	afx_msg void OnWatermarkspaceImage();
	afx_msg void OnWatermarkspaceoutImage();
	afx_msg void OnEmbossHsi();
	afx_msg void OnEdgeverticalhsiImage();
	afx_msg void OnEdgehorizontalhsiImage();
	afx_msg void OnImpressImage();
};

#ifndef _DEBUG  // ColorImageAlpha1View.cpp의 디버그 버전
inline CColorImageAlpha1Doc* CColorImageAlpha1View::GetDocument() const
   { return reinterpret_cast<CColorImageAlpha1Doc*>(m_pDocument); }
#endif


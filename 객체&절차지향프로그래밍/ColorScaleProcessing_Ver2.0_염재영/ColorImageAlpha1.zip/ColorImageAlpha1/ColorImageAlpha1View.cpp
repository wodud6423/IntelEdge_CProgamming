﻿
// ColorImageAlpha1View.cpp: CColorImageAlpha1View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ColorImageAlpha1.h"
#endif

#include "ColorImageAlpha1Doc.h"
#include "ColorImageAlpha1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CColorImageAlpha1View

IMPLEMENT_DYNCREATE(CColorImageAlpha1View, CView)

BEGIN_MESSAGE_MAP(CColorImageAlpha1View, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(IDM_EQUAL_IMAGE, &CColorImageAlpha1View::OnEqualImage)
	ON_COMMAND(IDM_GRAY_SCALE, &CColorImageAlpha1View::OnGrayScale)
	ON_COMMAND(IDM_ADDER_IMAGE, &CColorImageAlpha1View::OnAdderImage)
	ON_COMMAND(IDM_INVERSE_IMAGE, &CColorImageAlpha1View::OnInverseImage)
	ON_COMMAND(IDM_BINIZATION128_IMAGE, &CColorImageAlpha1View::OnBinization128Image)
	ON_COMMAND(IDM_BINIZATIONAVG_IMAGE, &CColorImageAlpha1View::OnBinizationavgImage)
	ON_COMMAND(IDM_BINIZATIONMID_IMAGE, &CColorImageAlpha1View::OnBinizationmidImage)
	ON_COMMAND(IDM_POSTER_IMAGE, &CColorImageAlpha1View::OnPosterImage)
	ON_COMMAND(IDM_ANDBIT_IMAGE, &CColorImageAlpha1View::OnAndbitImage)
	ON_COMMAND(IDM_ORBIT_IMAGE, &CColorImageAlpha1View::OnOrbitImage)
	ON_COMMAND(IDM_XORBIT_IMAGE, &CColorImageAlpha1View::OnXorbitImage)
	ON_COMMAND(IDM_MUL_IMAGE, &CColorImageAlpha1View::OnMulImage)
	ON_COMMAND(IDM_DIV_IMAGE, &CColorImageAlpha1View::OnDivImage)
	ON_COMMAND(IDM_PARABOLACAP_IMAGE, &CColorImageAlpha1View::OnParabolacapImage)
	ON_COMMAND(IDM_PARABOLACUP_IMAGE, &CColorImageAlpha1View::OnParabolacupImage)
	ON_COMMAND(IDM_GAMMA_IMAGE, &CColorImageAlpha1View::OnGammaImage)
	ON_COMMAND(IDM_BLUR_IMAGE, &CColorImageAlpha1View::OnBlurImage)
	ON_COMMAND(IDM_SHARP_IMAGE, &CColorImageAlpha1View::OnSharpImage)
	ON_COMMAND(IDM_EMBOSS_IMAGE, &CColorImageAlpha1View::OnEmbossImage)
	ON_COMMAND(IDM_GAUSS_IMAGE, &CColorImageAlpha1View::OnGaussImage)
	ON_COMMAND(IDM_HIGHSHARP_IMAGE, &CColorImageAlpha1View::OnHighsharpImage)
	ON_COMMAND(IDM_LOWSHARP_IMAGE, &CColorImageAlpha1View::OnLowsharpImage)
	ON_COMMAND(IDM_CHANGE_SATUR, &CColorImageAlpha1View::OnChangeSatur)
	ON_COMMAND(IDM_PICKORANGE_IMAGE, &CColorImageAlpha1View::OnPickorangeImage)
	ON_COMMAND(IDM_FORWARDREDUCT_IMAGE, &CColorImageAlpha1View::OnForwardreductImage)
	ON_COMMAND(IDM_FORWARDMEDREDUCT_IMAGE, &CColorImageAlpha1View::OnForwardmedreductImage)
	ON_COMMAND(IDM_FORWARDMIDREDUCT_IMAGE, &CColorImageAlpha1View::OnForwardmidreductImage)
	ON_COMMAND(IDM_FORWARDENLARGE_IMAGE, &CColorImageAlpha1View::OnForwardenlargeImage)
	ON_COMMAND(IDM_BACKWARDENLARGE_IMAGE, &CColorImageAlpha1View::OnBackwardenlargeImage)
	ON_COMMAND(IDM_BACKWARDENLARGEBOGAN_IMAGE, &CColorImageAlpha1View::OnBackwardenlargeboganImage)
	ON_COMMAND(IDM_FORWARDROTATE_IMAGE, &CColorImageAlpha1View::OnForwardrotateImage)
	ON_COMMAND(IDM_BACKWARDROTATE_IMAGE, &CColorImageAlpha1View::OnBackwardrotateImage)
	ON_COMMAND(IDM_ENLARGEROTATE_IMAGE, &CColorImageAlpha1View::OnEnlargerotateImage)
	ON_COMMAND(IDM_ENLARGEBOGANROTATE_IMAGE, &CColorImageAlpha1View::OnEnlargeboganrotateImage)
	ON_COMMAND(IDM_MOVE_IMAGE, &CColorImageAlpha1View::OnMoveImage)
	ON_COMMAND(IDM_SYMMETRY_IMAGE, &CColorImageAlpha1View::OnSymmetryImage)
	ON_COMMAND(IDM_ENDIN_IMAGE, &CColorImageAlpha1View::OnEndinImage)
	ON_COMMAND(IDM_DEFAULTSTRECH_IMAGE, &CColorImageAlpha1View::OnDefaultstrechImage)
	ON_COMMAND(IDM_HISTOSMOOTH_IMAGE, &CColorImageAlpha1View::OnHistosmoothImage)
	ON_COMMAND(IDM_EDGEVERTICAL_IMAGE, &CColorImageAlpha1View::OnEdgeverticalImage)
	ON_COMMAND(IDM_EDGEHORIZONTAL_IMAGE, &CColorImageAlpha1View::OnEdgehorizontalImage)
	ON_COMMAND(IDM_EDGEHOMOGEN_IMAGE, &CColorImageAlpha1View::OnEdgehomogenImage)
	ON_COMMAND(IDM_EDGESUB_IMAGE, &CColorImageAlpha1View::OnEdgesubImage)
	ON_COMMAND(IDM_EDGEFIRSTDERIVATIVE_IMAGE, &CColorImageAlpha1View::OnEdgefirstderivativeImage)
	ON_COMMAND(IDM_EDGELAPLACE_IMAGE, &CColorImageAlpha1View::OnEdgelaplaceImage)
	ON_COMMAND(IDM_EDGELOG_IMAGE, &CColorImageAlpha1View::OnEdgelogImage)
	ON_COMMAND(IDM_EDGEDOG_IMAGE, &CColorImageAlpha1View::OnEdgedogImage)
	ON_COMMAND(IDM_MOPING_IMAGE, &CColorImageAlpha1View::OnMopingImage)
	ON_COMMAND(IDM_SPECIFICATION_IMAGE, &CColorImageAlpha1View::OnSpecificationImage)
	ON_COMMAND(IDM_COLOROUT_IMAGE, &CColorImageAlpha1View::OnColoroutImage)
	ON_COMMAND(IDM_EMBOSSHSI_IMAGE, &CColorImageAlpha1View::OnEmbosshsiImage)
	ON_COMMAND(IDM_WATERMARKSPACE_IMAGE, &CColorImageAlpha1View::OnWatermarkspaceImage)
	ON_COMMAND(IDM_WATERMARKSPACEOUT_IMAGE, &CColorImageAlpha1View::OnWatermarkspaceoutImage)
	ON_COMMAND(IDM_EMBOSS_HSI, &CColorImageAlpha1View::OnEmbossHsi)
	ON_COMMAND(IDM_EDGEVERTICALHSI_IMAGE, &CColorImageAlpha1View::OnEdgeverticalhsiImage)
	ON_COMMAND(IDM_EDGEHORIZONTALHSI_IMAGE, &CColorImageAlpha1View::OnEdgehorizontalhsiImage)
	ON_COMMAND(IDM_IMPRESS_IMAGE, &CColorImageAlpha1View::OnImpressImage)
END_MESSAGE_MAP()

// CColorImageAlpha1View 생성/소멸

CColorImageAlpha1View::CColorImageAlpha1View() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CColorImageAlpha1View::~CColorImageAlpha1View()
{
}

BOOL CColorImageAlpha1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CColorImageAlpha1View 그리기

void CColorImageAlpha1View::OnDraw(CDC* pDC)
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	/////////////////////
	/// 성능 개선을 위한 더블 버퍼링 
	////////////////////
	int i, k;
	unsigned char R, G, B;
	int count = 0;
	int histoR[256] = { 0, }, histoG[256] = { 0, }, histoB[256] = { 0, };
	int maxR, maxG, maxB;

	maxR = maxG = maxB = 0;
	// 메모리 DC 선언
	CDC memDC;
	CBitmap* pOldBitmap, bitmap;

	// 화면 DC와 호환되는 메모리 DC 객체를 생성
	memDC.CreateCompatibleDC(pDC);

	// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	bitmap.CreateCompatibleBitmap(pDC, pDoc->m_inW, pDoc->m_inH);

	pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, pDoc->m_inW, pDoc->m_inH, WHITENESS); // 흰색으로 초기화


	// 출력 영상의 크기를 자동 조절
	double MAXSIZE = 800;  // 필요시 실 모니터 또는 화면의 해상도에 따라서 변경 가능!
	int inH = pDoc->m_inH;
	int inW = pDoc->m_inW;
	double hop = 1.0; // 기본

	if (inH > MAXSIZE || inW > MAXSIZE) {
		// hop을 새로 계산.
		if (inW > inH)
			hop = (inW / MAXSIZE);
		else
			hop = (inH / MAXSIZE);

		inW = (int)(inW / hop);
		inH = (int)(inH / hop);
	}

	// 메모리 DC에 그리기
	for (i = 0; i < inH; i++) {
		for (k = 0; k < inW; k++) {
			R = pDoc->m_inImageR[(int)(i * hop)][(int)(k * hop)];
			G = pDoc->m_inImageG[(int)(i * hop)][(int)(k * hop)];
			B = pDoc->m_inImageB[(int)(i * hop)][(int)(k * hop)];
			memDC.SetPixel(k, i, RGB(R, G, B));
			histoR[R]++;
			histoG[G]++;
			histoB[B]++;
			if (maxR <= histoR[R])
				maxR = histoR[R];
			if (maxG <= histoG[G])
				maxG = histoG[G];
			if (maxB <= histoB[B])
				maxB = histoB[B];
		}
	}

	// 메모리 DC를 화면 DC에 고속 복사
	pDC->BitBlt(5, 5, pDoc->m_inW, pDoc->m_inH, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();
	/////////////////////
	////
	////////////////////
	if (pDoc->m_inImageR != NULL) {
		for (int i = 0; i < 256; i++) {
			for (int a = 0; a < 3; a++) {
				///히스토그램 축 생성
				pDC->SetPixel((int)(10 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(4 + 256 / 3 + 10 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + 10 + i / 3), 15 + 700 + a, RGB(i, i, i));
			}
			///히스토그램 출력
			for (int k = 0; k < histoR[i]; k++) {
				pDC->SetPixel((int)(10 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
			}
			histoR[i] = 0;
			for (int k = 0; k < histoG[i]; k++) {
				pDC->SetPixel((int)(4 + 256 / 3 + 10 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
			}
			histoG[i] = 0;
			for (int k = 0; k < histoB[i]; k++) {
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + 10 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
			}
			histoB[i] = 0;
		}

		for (int a = 0; a < 3; a++)
			for (count = 0; count < int(pDoc->m_inH / 2); count++)
				pDC->SetPixel(2 + a, 10 + 700 - count, RGB(0, 0, 0));
	}
	maxR = maxG = maxB = 0;
	count = 0;

	/////////////////////
	////
	////////////////////
	int checkeffect = 0;
	// 화면 DC와 호환되는 메모리 DC 객체를 생성
	memDC.CreateCompatibleDC(pDC);

	// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	bitmap.CreateCompatibleBitmap(pDC, pDoc->m_effectW, pDoc->m_effectH);

	pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, pDoc->m_effectW, pDoc->m_effectH, WHITENESS); // 흰색으로 초기화

	int effectH = pDoc->m_effectH;
	int effectW = pDoc->m_effectW;
	hop = 1.0; // 기본

	if (effectH > MAXSIZE || effectW > MAXSIZE) {
		// hop을 새로 계산.
		if (effectW > effectH)
			hop = (effectW / MAXSIZE);
		else
			hop = (effectH / MAXSIZE);

		effectW = (int)(effectW / hop);
		effectH = (int)(effectH / hop);
	}

	// 메모리 DC에 그리기
	for (i = 0; i < effectH; i++) {
		for (k = 0; k < effectW; k++) {
			R = pDoc->m_effectImageR[(int)(i * hop)][(int)(k * hop)];
			G = pDoc->m_effectImageG[(int)(i * hop)][(int)(k * hop)];
			B = pDoc->m_effectImageB[(int)(i * hop)][(int)(k * hop)];
			memDC.SetPixel(k, i, RGB(R, G, B));
			histoR[R]++;
			histoG[G]++;
			histoB[B]++;
			if (maxR <= histoR[R])
				maxR = histoR[R];
			if (maxG <= histoG[G])
				maxG = histoG[G];
			if (maxB <= histoB[B])
				maxB = histoB[B];
		}
	}
	// 메모리 DC를 화면 DC에 고속 복사
	pDC->BitBlt(inW + 10, 5, pDoc->m_effectW, pDoc->m_effectH, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();
	/////////////////////
	////
	////////////////////

	if (pDoc->m_effectImageR != NULL) {
		checkeffect = 1;
		for (int i = 0; i < 256; i++) {
			for (int a = 0; a < 3; a++) {
				///히스토그램 축 생성
				pDC->SetPixel((int)(pDoc->m_inW + 20 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + 20 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + 20 + i / 3), 15 + 700 + a, RGB(i, i, i));
			}
			///히스토그램 출력
			for (int k = 0; k < histoR[i]; k++) {
				pDC->SetPixel((int)(pDoc->m_inW + 20 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
			}
			histoR[i] = 0;
			for (int k = 0; k < histoG[i]; k++) {
				pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + 20 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
			}
			histoG[i] = 0;
			for (int k = 0; k < histoB[i]; k++) {
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + 20 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
			}
			histoB[i] = 0;
		}

		for (int a = 0; a < 3; a++)
			for (count = 0; count < int(pDoc->m_inH / 2); count++)
				pDC->SetPixel(pDoc->m_inW + 12 + a, 10 + 700 - count, RGB(0, 0, 0));
	}
	maxR = maxG = maxB = 0;
	count = 0;
	/////////////////////
	////
	////////////////////
	memDC.CreateCompatibleDC(pDC);

	// 마찬가지로 화면 DC와 호환되는 Bitmap 생성
	bitmap.CreateCompatibleBitmap(pDC, pDoc->m_outW, pDoc->m_outH);

	pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, pDoc->m_outW, pDoc->m_outH, WHITENESS); // 흰색으로 초기화

	int outH = pDoc->m_outH;
	int outW = pDoc->m_outW;
	hop = 1.0; // 기본

	if (outH > MAXSIZE || outW > MAXSIZE) {
		// hop을 새로 계산.
		if (outW > outH)
			hop = (outW / MAXSIZE);
		else
			hop = (outH / MAXSIZE);

		outW = (int)(outW / hop);
		outH = (int)(outH / hop);
	}

	// 메모리 DC에 그리기
	for (i = 0; i < outH; i++) {
		for (k = 0; k < outW; k++) {
			R = pDoc->m_outImageR[(int)(i * hop)][(int)(k * hop)];
			G = pDoc->m_outImageG[(int)(i * hop)][(int)(k * hop)];
			B = pDoc->m_outImageB[(int)(i * hop)][(int)(k * hop)];
			histoR[R]++;
			histoG[G]++;
			histoB[B]++;
			if (maxR <= histoR[R])
				maxR = histoR[R];
			if (maxG <= histoG[G])
				maxG = histoG[G];
			if (maxB <= histoB[B])
				maxB = histoB[B];
			memDC.SetPixel(k, i, RGB(R, G, B));
		}
	}
	// 메모리 DC를 화면 DC에 고속 복사
	pDC->BitBlt(inW +effectW+ 15, 5, pDoc->m_outW, pDoc->m_outH, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldBitmap);
	memDC.DeleteDC();
	bitmap.DeleteObject();
	/////////////////////
	////
	////////////////////
	if (pDoc->m_outImageR != NULL) {
		for (int i = 0; i < 256; i++) {
			for (int a = 0; a < 3; a++) {
				///히스토그램 축 생성
				pDC->SetPixel((int)(checkeffect*pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(4 + 256 / 3 + checkeffect *pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 700 + a, RGB(i, i, i));
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + checkeffect * pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 700 + a, RGB(i, i, i));
			}
			///히스토그램 출력
			for (int k = 0; k < histoR[i]; k++) {
				pDC->SetPixel((int)(checkeffect * pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
			}
			histoR[i] = 0;
			for (int k = 0; k < histoG[i]; k++) {
				pDC->SetPixel((int)(4 + 256 / 3 + checkeffect * pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
			}
			histoG[i] = 0;
			for (int k = 0; k < histoB[i]; k++) {
				pDC->SetPixel((int)(8 + 256 * 2 / 3 + checkeffect * pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 700 - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
			}
			histoB[i] = 0;
		}

		for (int a = 0; a < 3; a++)
			for (count = 0; count < int(pDoc->m_inH / 2); count++)
				pDC->SetPixel(checkeffect * pDoc->m_inW + pDoc->m_inW + 22 + a, 10 + 700 - count, RGB(0, 0, 0));

	}
maxR = maxG = maxB = 0;
count = 0;
checkeffect = 0;
pDoc->m_effectH = pDoc->m_effectW = 0;
pDoc->m_effectImageR = NULL;
pDoc->m_effectImageG = NULL;
pDoc->m_effectImageB = NULL;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 

	//int R, G, B;
	//int count = 0;
	//int histoR[256] = { 0, }, histoG[256] = { 0, }, histoB[256] = { 0, };
	//int maxR, maxG, maxB;
	//maxR = maxG = maxB = 0;
	//for (int i = 0; i < pDoc->m_inH; i++) {
	//	for (int k = 0; k < pDoc->m_inW; k++) {
	//		R = pDoc->m_inImageR[i][k];
	//		G = pDoc->m_inImageG[i][k];
	//		B = pDoc->m_inImageB[i][k];
	//		pDC->SetPixel(k + 10, i + 10, RGB(R, G, B));
	//		histoR[R]++;
	//		histoG[G]++;
	//		histoB[B]++;
	//		if (maxR <= histoR[R])
	//			maxR = histoR[R];
	//		if (maxG <= histoG[G])
	//			maxG = histoG[G];
	//		if (maxB <= histoB[B])
	//			maxB = histoB[B];
	//	}
	//}
	//if (pDoc->m_inImageR != NULL) {
	//	for (int i = 0; i < 256; i++) {
	//		for (int a = 0; a < 3; a++) {
	//			///히스토그램 축 생성
	//			pDC->SetPixel((int)(10 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(4 + 256 / 3 + 10 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + 10 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			if (count >= pDoc->m_inH / 2)
	//				continue;
	//			pDC->SetPixel(2 + a, 10 + 2 * pDoc->m_inH - count, RGB(0, 0, 0));
	//		}
	//		count++;
	//		///히스토그램 출력
	//		for (int k = 0; k < histoR[i]; k++) {
	//			pDC->SetPixel((int)(10 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
	//		}
	//		histoR[i] = 0;
	//		for (int k = 0; k < histoG[i]; k++) {
	//			pDC->SetPixel((int)(4 + 256 / 3 + 10 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
	//		}
	//		histoG[i] = 0;
	//		for (int k = 0; k < histoB[i]; k++) {
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + 10 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
	//		}
	//		histoB[i] = 0;
	//	}
	//}
	//maxR = maxG = maxB = 0;
	//count = 0;

	//for (int i = 0; i < pDoc->m_effectH; i++) {
	//	for (int k = 0; k < pDoc->m_effectW; k++) {
	//		R = pDoc->m_effectImageR[i][k];
	//		G = pDoc->m_effectImageG[i][k];
	//		B = pDoc->m_effectImageB[i][k];
	//		pDC->SetPixel(pDoc->m_inW + k + 20, i + 10, RGB(R, G, B));
	//		histoR[R]++;
	//		histoG[G]++;
	//		histoB[B]++;
	//		if (maxR <= histoR[R])
	//			maxR = histoR[R];
	//		if (maxG <= histoG[G])
	//			maxG = histoG[G];
	//		if (maxB <= histoB[B])
	//			maxB = histoB[B];
	//	}
	//}
	//if (pDoc->m_effectImageR != NULL) {
	//	for (int i = 0; i < 256; i++) {
	//		for (int a = 0; a < 3; a++) {
	//			///히스토그램 축 생성
	//			pDC->SetPixel((int)(pDoc->m_inW + 20 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + 20 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + 20 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			if (count >= pDoc->m_inH / 2)
	//				continue;
	//			pDC->SetPixel(pDoc->m_inW + 12 + a, 10 + 2 * pDoc->m_inH - count, RGB(0, 0, 0));
	//		}
	//		count++;
	//		///히스토그램 출력
	//		for (int k = 0; k < histoR[i]; k++) {
	//			pDC->SetPixel((int)(pDoc->m_inW + 20 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
	//		}
	//		histoR[i] = 0;
	//		for (int k = 0; k < histoG[i]; k++) {
	//			pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + 20 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
	//		}
	//		histoG[i] = 0;
	//		for (int k = 0; k < histoB[i]; k++) {
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + 20 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
	//		}
	//		histoB[i] = 0;
	//	}
	//}
	//maxR = maxG = maxB = 0;
	//count = 0;

	//for (int i = 0; i < pDoc->m_outH; i++) {
	//	for (int k = 0; k < pDoc->m_outW; k++) {
	//		R = pDoc->m_outImageR[i][k];
	//		G = pDoc->m_outImageG[i][k];
	//		B = pDoc->m_outImageB[i][k];
	//		pDC->SetPixel(pDoc->m_effectW + pDoc->m_inW + k + 30, i + 10, RGB(R, G, B));
	//		histoR[R]++;
	//		histoG[G]++;
	//		histoB[B]++;
	//		if (maxR <= histoR[R])
	//			maxR = histoR[R];
	//		if (maxG <= histoG[G])
	//			maxG = histoG[G];
	//		if (maxB <= histoB[B])
	//			maxB = histoB[B];
	//	}
	//}
	//if (pDoc->m_outImageR != NULL) {
	//	for (int i = 0; i < 256; i++) {
	//		for (int a = 0; a < 3; a++) {
	//			///히스토그램 축 생성
	//			pDC->SetPixel((int)(pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + pDoc->m_inW + 30 + i / 3), 15 + 2 * pDoc->m_inH + a, RGB(i, i, i));
	//			if (count >= pDoc->m_inH / 2)
	//				continue;
	//			pDC->SetPixel(pDoc->m_inW + pDoc->m_inW + 22 + a, 10 + 2 * pDoc->m_inH - count,	RGB(0, 0, 0));
	//		}
	//		count++;
	//		///히스토그램 출력
	//		for (int k = 0; k < histoR[i]; k++) {
	//			pDC->SetPixel((int)(pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxR)), RGB(255, 0, 0));
	//		}
	//		histoR[i] = 0;
	//		for (int k = 0; k < histoG[i]; k++) {
	//			pDC->SetPixel((int)(4 + 256 / 3 + pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxG)), RGB(0, 255, 0));
	//		}
	//		histoG[i] = 0;
	//		for (int k = 0; k < histoB[i]; k++) {
	//			pDC->SetPixel((int)(8 + 256 * 2 / 3 + pDoc->m_inW + pDoc->m_inW + 30 + i / 3), (int)(10 + 2 * pDoc->m_inH - k * pDoc->m_inH / (2 * maxB)), RGB(0, 0, 255));
	//		}
	//		histoB[i] = 0;
	//	}
	//}
	//maxR = maxG = maxB = 0;
	//count = 0;



}


// CColorImageAlpha1View 인쇄

BOOL CColorImageAlpha1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CColorImageAlpha1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CColorImageAlpha1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}


// CColorImageAlpha1View 진단

#ifdef _DEBUG
void CColorImageAlpha1View::AssertValid() const
{
	CView::AssertValid();
}

void CColorImageAlpha1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CColorImageAlpha1Doc* CColorImageAlpha1View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CColorImageAlpha1Doc)));
	return (CColorImageAlpha1Doc*)m_pDocument;
}
#endif //_DEBUG


// CColorImageAlpha1View 메시지 처리기



void CColorImageAlpha1View::OnEqualImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEqualImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnGrayScale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnGrayScale();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnAdderImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnAdderImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnInverseImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnInverseImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBinization128Image()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBinization128Image();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBinizationavgImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBinizationavgImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBinizationmidImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBinizationmidImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnPosterImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnPosterImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnAndbitImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnAndbitImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnOrbitImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnOrbitImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnXorbitImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnXorbitImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnMulImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnMulImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnDivImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnDivImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnParabolacapImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnParabolacapImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnParabolacupImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnParabolacupImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnGammaImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnGammaImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBlurImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBlurImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnSharpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnSharpImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEmbossImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEmbossImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnGaussImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnGaussImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnHighsharpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnHighsharpImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnLowsharpImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnLowsharpImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnChangeSatur()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnChangeSatur();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnPickorangeImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnPickorangeImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnForwardreductImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnForwardreductImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnForwardmedreductImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnForwardmedreductImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnForwardmidreductImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnForwardmidreductImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnForwardenlargeImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnForwardenlargeImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBackwardenlargeImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBackwardenlargeImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBackwardenlargeboganImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBackwardenlargeboganImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnForwardrotateImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnForwardrotateImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnBackwardrotateImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnBackwardrotateImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEnlargerotateImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEnlargerotateImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEnlargeboganrotateImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEnlargeboganrotateImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnMoveImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnMoveImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnSymmetryImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnSymmetryImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEndinImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEndinImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnDefaultstrechImage()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnDefaultstrechImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnHistosmoothImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnHistosmoothImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgeverticalImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgeverticalImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgehorizontalImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgehorizontalImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgehomogenImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgehomogenImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgesubImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgesubImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgefirstderivativeImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgefirstderivativeImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgelaplaceImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgelaplaceImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgelogImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgelogImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgedogImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgedogImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnMopingImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnMopingImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnSpecificationImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnSpecificationImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnColoroutImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnColoroutImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEmbosshsiImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEmbosshsiImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnWatermarkspaceImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnWatermarkspaceImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnWatermarkspaceoutImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnWatermarkspaceoutImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEmbossHsi()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEmbossHsi();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgeverticalhsiImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgeverticalhsiImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnEdgehorizontalhsiImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnEdgehorizontalhsiImage();
	Invalidate(TRUE);
}


void CColorImageAlpha1View::OnImpressImage()
{
	CColorImageAlpha1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->OnImpressImage();
	Invalidate(TRUE);
}

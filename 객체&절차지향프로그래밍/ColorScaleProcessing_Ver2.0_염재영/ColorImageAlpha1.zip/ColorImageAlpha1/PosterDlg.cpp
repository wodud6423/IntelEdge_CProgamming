﻿// PosterDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "PosterDlg.h"


// CPosterDlg 대화 상자

IMPLEMENT_DYNAMIC(CPosterDlg, CDialog)

CPosterDlg::CPosterDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_POTSER, pParent)
	, m_posterlevel(0)
{

}

CPosterDlg::~CPosterDlg()
{
}

void CPosterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_posterlevel);
	DDV_MinMaxInt(pDX, m_posterlevel, 1, 255);
}


BEGIN_MESSAGE_MAP(CPosterDlg, CDialog)
END_MESSAGE_MAP()


// CPosterDlg 메시지 처리기

﻿#pragma once
#include "afxdialogex.h"


// CLowsharpDlg 대화 상자

class CLowsharpDlg : public CDialog
{
	DECLARE_DYNAMIC(CLowsharpDlg)

public:
	CLowsharpDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CLowsharpDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_LOWSHARP };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	double m_alpha;
};

﻿
// ColorImageAlpha1Doc.h: CColorImageAlpha1Doc 클래스의 인터페이스
//


#pragma once


class CColorImageAlpha1Doc : public CDocument
{
protected: // serialization에서만 만들어집니다.
	CColorImageAlpha1Doc() noexcept;
	DECLARE_DYNCREATE(CColorImageAlpha1Doc)

// 특성입니다.
public:

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// 구현입니다.
public:
	virtual ~CColorImageAlpha1Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// 검색 처리기에 대한 검색 콘텐츠를 설정하는 도우미 함수
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	unsigned char** m_inImageR = NULL;
	unsigned char** m_inImageG = NULL;
	unsigned char** m_inImageB = NULL;
	int m_outImage;
	unsigned char** m_outImageR = NULL;
	unsigned char** m_outImageG = NULL;
	unsigned char** m_outImageB = NULL;
	int m_inH = 0 ;
	int m_inW = 0;
	int m_outH = 0;
	int m_outW = 0;
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	unsigned char** OnMalloc2D(int h, int w);
	void OnFree2d(unsigned char** memory, int h);
	virtual void OnCloseDocument();
	void OnEqualImage();
	void OnFreeOutImage();
	void OnGrayScale();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	void OnAdderImage();
	void OnInverseImage();
	void OnBinization128Image();
	void OnBinizationavgImage();
	int OnMediumVal();
	void OnBinizationmidImage();
	void OnQuickSort(unsigned char*& arr, int L, int R);
	void OnPosterImage();
	void OnAndbitImage();
	void OnOrbitImage();
	void OnXorbitImage();
	void OnMulImage();
	void OnDivImage();
	void OnParabolacapImage();
	void OnParabolacupImage();
	void OnGammaImage();
	void OnBlurImage();
	double** OnMallocDouble2D(int h, int w);
	void OnFreeDouble2D(double** memory, int h);
	void OnSharpImage();
	void OnEmbossImage();
	void OnGaussImage();
	void OnHighsharpImage();
	void OnLowsharpImage();
	void OnChangeSatur();
	double* RGB2HSI(int R, int G, int B);
	unsigned char* HSI2RGB(double H, double S, double I);
	void OnPickorangeImage();
	void OnForwardreductImage();
	void OnForwardmedreductImage();
	void OnForwardmidreductImage();
	void OnForwardenlargeImage();
	void OnBackwardenlargeImage();
	void OnBackwardenlargeboganImage();
	void OnForwardrotateImage();
	void OnBackwardrotateImage();
	void OnEnlargerotateImage();
	void OnEnlargeboganrotateImage();
	void OnMoveImage();
	void OnSymmetryImage();
	void OnEndinImage();
	void OnDefaultstrechImage();
	void OnHistosmoothImage();
	void OnEdgeverticalImage();
	void OnEdgehorizontalImage();
	void OnEdgehomogenImage();
	void OnEdgesubImage();
	void OnEdgefirstderivativeImage();
	void OnEdgelaplaceImage();
	void OnEdgelogImage();
	void OnEdgedogImage();
	int m_effectH = 0;
	int m_effectW = 0;
	unsigned char** m_effectImage; // 사용 안하는 변수!
	unsigned char** m_effectImageR = NULL;
	unsigned char** m_effectImageG = NULL;
	unsigned char** m_effectImageB = NULL;
	void OnMopingImage();
	BOOL OnEffectImageload();
	void OnFreeEffectImage();
	void OnForwardReductEffectImage();
	void OnSpecificationImage();
	void OnColoroutImage();
	void OnEmbosshsiImage();
	void OnWatermarkspaceImage();
	void OnWatermarkspaceoutImage();
	int m_effectscaleh = 0;
	int m_effectscalew = 0;
	void OnEmbossHsi();
	void OnEdgeverticalhsiImage();
	void OnEdgehorizontalhsiImage();
	void OnImpressImage();
};

﻿// WaterimageoutDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "WaterimageoutDlg.h"


// CWaterimageoutDlg 대화 상자

IMPLEMENT_DYNAMIC(CWaterimageoutDlg, CDialog)

CWaterimageoutDlg::CWaterimageoutDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_WATERIMAGEOUT, pParent)
	, m_waterH(0)
	, m_waterW(0)
	, m_reductscale(0)
{

}

CWaterimageoutDlg::~CWaterimageoutDlg()
{
}

void CWaterimageoutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT3, m_waterH);
	DDX_Text(pDX, IDC_EDIT2, m_waterW);
	DDX_Text(pDX, IDC_EDIT1, m_reductscale);
	DDV_MinMaxInt(pDX, m_reductscale, 1, INT_MAX);
}


BEGIN_MESSAGE_MAP(CWaterimageoutDlg, CDialog)
END_MESSAGE_MAP()


// CWaterimageoutDlg 메시지 처리기

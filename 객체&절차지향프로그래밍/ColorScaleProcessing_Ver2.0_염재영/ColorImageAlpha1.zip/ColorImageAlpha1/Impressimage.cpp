﻿// Impressimage.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "Impressimage.h"


// CImpressimage 대화 상자

IMPLEMENT_DYNAMIC(CImpressimage, CDialog)

CImpressimage::CImpressimage(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_IMPRESSIMAGE, pParent)
	, m_RST(0)
	, m_RED(0)
	, m_GST(0)
	, m_GED(0)
	, m_BST(0)
	, m_BED(0)
{

}

CImpressimage::~CImpressimage()
{
}

void CImpressimage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_RST);
	DDV_MinMaxInt(pDX, m_RST, 0, 255);
	DDX_Text(pDX, IDC_EDIT2, m_RED);
	DDV_MinMaxInt(pDX, m_RED, 0, 255);
	DDX_Text(pDX, IDC_EDIT5, m_GST);
	DDV_MinMaxInt(pDX, m_GST, 0, 255);
	DDX_Text(pDX, IDC_EDIT6, m_GED);
	DDV_MinMaxInt(pDX, m_GED, 0, 255);
	DDX_Text(pDX, IDC_EDIT7, m_BST);
	DDV_MinMaxInt(pDX, m_BST, 0, 255);
	DDX_Text(pDX, IDC_EDIT8, m_BED);
	DDV_MinMaxInt(pDX, m_BED, 0, 255);
}


BEGIN_MESSAGE_MAP(CImpressimage, CDialog)
END_MESSAGE_MAP()


// CImpressimage 메시지 처리기

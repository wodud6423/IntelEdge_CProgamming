﻿// SharpmaskDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "SharpmaskDlg.h"


// CSharpmaskDlg 대화 상자

IMPLEMENT_DYNAMIC(CSharpmaskDlg, CDialog)

CSharpmaskDlg::CSharpmaskDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_SHARPMASK, pParent)
	, m_sharpmask(0)
{

}

CSharpmaskDlg::~CSharpmaskDlg()
{
}

void CSharpmaskDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_sharpmask);
	DDV_MinMaxInt(pDX, m_sharpmask, 1, 2);
}


BEGIN_MESSAGE_MAP(CSharpmaskDlg, CDialog)
END_MESSAGE_MAP()


// CSharpmaskDlg 메시지 처리기

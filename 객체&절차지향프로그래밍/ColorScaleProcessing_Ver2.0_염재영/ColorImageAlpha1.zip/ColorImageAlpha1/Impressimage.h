﻿#pragma once
#include "afxdialogex.h"


// CImpressimage 대화 상자

class CImpressimage : public CDialog
{
	DECLARE_DYNAMIC(CImpressimage)

public:
	CImpressimage(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CImpressimage();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_IMPRESSIMAGE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	int m_RST;
	int m_RED;
	int m_GST;
	int m_GED;
	int m_BST;
	int m_BED;
};

﻿// GammaDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "GammaDlg.h"


// CGammaDlg 대화 상자

IMPLEMENT_DYNAMIC(CGammaDlg, CDialog)

CGammaDlg::CGammaDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_GAMMA, pParent)
	, m_gamma(0)
{

}

CGammaDlg::~CGammaDlg()
{
}

void CGammaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_gamma);
	DDV_MinMaxDouble(pDX, m_gamma, 0.2, 1.8);
}


BEGIN_MESSAGE_MAP(CGammaDlg, CDialog)
END_MESSAGE_MAP()


// CGammaDlg 메시지 처리기

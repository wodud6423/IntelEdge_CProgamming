﻿// RealcoloroutDlg.cpp: 구현 파일
//

#include "pch.h"
#include "ColorImageAlpha1.h"
#include "afxdialogex.h"
#include "RealcoloroutDlg.h"


// CRealcoloroutDlg 대화 상자

IMPLEMENT_DYNAMIC(CRealcoloroutDlg, CDialog)

CRealcoloroutDlg::CRealcoloroutDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_REALCOLOROUT, pParent)
	, m_colorval(0)
{

}

CRealcoloroutDlg::~CRealcoloroutDlg()
{
}

void CRealcoloroutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_colorval);
	DDV_MinMaxInt(pDX, m_colorval, 1, 7);
}


BEGIN_MESSAGE_MAP(CRealcoloroutDlg, CDialog)
END_MESSAGE_MAP()


// CRealcoloroutDlg 메시지 처리기
